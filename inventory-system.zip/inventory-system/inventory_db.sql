-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 01, 2026 at 05:33 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `inventory_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `audit_log`
--

CREATE TABLE `audit_log` (
  `log_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `action` enum('create','update','delete','login') NOT NULL,
  `table_name` varchar(50) DEFAULT NULL,
  `record_id` int(11) DEFAULT NULL,
  `details` text DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `audit_log`
--

INSERT INTO `audit_log` (`log_id`, `user_id`, `action`, `table_name`, `record_id`, `details`, `created_at`) VALUES
(1, 1, 'login', 'users', NULL, 'Password accepted, OTP sent', '2026-10-30 00:39:23'),
(2, 2, 'login', 'users', NULL, 'Password accepted, OTP sent', '2026-10-30 00:41:43'),
(3, 1, 'login', 'users', NULL, 'Password accepted, OTP sent', '2026-10-30 00:43:55'),
(4, 1, 'login', 'users', NULL, 'Password accepted, OTP sent', '2026-10-30 20:59:53'),
(5, 1, 'login', 'users', NULL, 'Password accepted, OTP sent', '2026-10-30 21:56:55'),
(6, 2, 'login', 'users', NULL, 'Password accepted, OTP sent', '2026-11-01 17:38:32'),
(7, 2, 'login', 'users', NULL, 'Password accepted, OTP sent', '2026-11-01 17:58:04'),
(8, 1, 'login', 'users', NULL, 'Password accepted, OTP sent', '2026-11-01 18:01:12'),
(9, 2, 'login', 'users', NULL, 'Password accepted, OTP sent', '2026-11-01 18:02:12'),
(10, 1, 'login', 'users', NULL, 'Password accepted, OTP sent', '2026-11-01 18:15:05'),
(11, 1, 'update', 'company_profile', NULL, 'Updated company profile', '2026-11-01 18:16:24'),
(12, 3, 'login', 'users', NULL, 'Password accepted, OTP sent', '2026-11-01 18:18:40'),
(13, 4, 'login', 'users', NULL, 'Password accepted, OTP sent', '2026-11-01 18:20:51'),
(14, 5, 'login', 'users', NULL, 'Password accepted, OTP sent', '2026-11-01 18:30:10'),
(15, 1, 'login', 'users', NULL, 'Password accepted, OTP sent', '2026-11-01 18:31:11'),
(16, 1, 'update', 'company_profile', NULL, 'Updated company profile', '2026-11-01 18:41:07'),
(17, 1, 'update', 'company_profile', NULL, 'Updated company profile', '2026-11-01 18:41:31'),
(18, 1, 'login', 'users', NULL, 'Password accepted, OTP sent', '2026-11-01 19:03:52'),
(19, 1, 'login', 'users', NULL, 'Password accepted, OTP sent', '2026-11-01 19:10:19'),
(20, 1, 'login', 'users', NULL, 'Password accepted, OTP sent', '2026-11-01 19:16:42'),
(21, 1, 'login', 'users', NULL, 'Password accepted, OTP sent', '2026-11-01 19:25:06'),
(22, 3, 'login', 'users', NULL, 'Password accepted, OTP sent', '2026-11-01 19:30:56'),
(23, 4, 'login', 'users', NULL, 'Password accepted, OTP sent', '2026-11-01 19:32:01');

-- --------------------------------------------------------

--
-- Table structure for table `company_profile`
--

CREATE TABLE `company_profile` (
  `profile_id` int(11) NOT NULL DEFAULT 1,
  `company_name` varchar(150) NOT NULL,
  `logo_path` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `mission` text DEFAULT NULL,
  `services` text DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `email` varchar(150) DEFAULT NULL,
  `opening_hours` varchar(100) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `company_profile`
--

INSERT INTO `company_profile` (`profile_id`, `company_name`, `logo_path`, `description`, `mission`, `services`, `address`, `phone`, `email`, `opening_hours`, `updated_by`, `updated_at`) VALUES
(1, 'Stockmore Inventory System', '', 'A simple, reliable stock manager.', 'Keep your inventory accurate and up to date.', '', 'Nairobi, Kenya', '+254 114 276 607', 'info@example.com', 'Mon-Sat, 8:00-18:00', 1, '2026-11-01 18:41:31');

-- --------------------------------------------------------

--
-- Table structure for table `items`
--

CREATE TABLE `items` (
  `item_id` int(11) NOT NULL,
  `sku` varchar(50) NOT NULL,
  `name` varchar(150) NOT NULL,
  `category` varchar(80) DEFAULT NULL,
  `supplier_id` int(11) DEFAULT NULL,
  `unit_price` decimal(10,2) NOT NULL,
  `min_stock` int(11) DEFAULT 5,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `otp_codes`
--

CREATE TABLE `otp_codes` (
  `otp_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `code_hash` varchar(255) NOT NULL,
  `expires_at` datetime NOT NULL,
  `attempts` int(11) DEFAULT 0,
  `is_used` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `otp_codes`
--

INSERT INTO `otp_codes` (`otp_id`, `user_id`, `code_hash`, `expires_at`, `attempts`, `is_used`) VALUES
(1, 1, '$2y$10$cAArOmwcOe4cImcwjvdmqOxK.Z6U1DZpfx38jPcYdUULFHHMzvqd.', '2026-10-29 22:44:23', 0, 1),
(2, 2, '$2y$10$EQTCmnaMHkyHeqUuAddEJORfgqpFFzsN61PMPCbVp7QH4DW2QhW6W', '2026-10-29 22:46:43', 0, 1),
(3, 1, '$2y$10$SHYVeRehQShBKvZk3KbVRuuMxTQ28KN71hPXR7/C.4tX5b8SCMehK', '2026-10-29 22:48:55', 0, 1),
(4, 1, '$2y$10$BvrjBIUtNG2KSNy6o0m1POEKnm1sCY7WFEaSUeuZsMpOUDjbnvCZO', '2026-10-30 19:04:53', 0, 1),
(5, 1, '$2y$10$HsQlXyFl5f5xBuEleHPcieYbjbFNZjDaD5V/EtDk3C.ddbCVu//8C', '2026-10-30 20:01:55', 0, 1),
(6, 2, '$2y$10$kM9urUoaOv57/e35B8gG9OfNUvjIm9EAnwmPpVNH.v55ZSxSiAmga', '2026-11-01 15:43:32', 0, 1),
(7, 2, '$2y$10$hTt5ewi8XG8VDJSn0qLBqeBX7s0rx5shFsva7fTPYb.xZLsJ2Btom', '2026-11-01 16:03:04', 0, 1),
(8, 1, '$2y$10$R7kepHzJDERB1J7kj1hyZ.6lXsYrn7SwBv5PIqUlME02thFnEwEHy', '2026-11-01 16:06:12', 0, 1),
(9, 2, '$2y$10$ZoSm9GaxFDyU7iTJmbSeH.DiGRzn7E0cns.QttmKYDGUfk0AUmsXq', '2026-11-01 16:07:12', 0, 1),
(10, 1, '$2y$10$8gxSoUUgTvJkRYQQV59UaOX0iv40qjkZ2bR4drDihtbHfsUSGbLKO', '2026-11-01 16:20:05', 0, 1),
(11, 3, '$2y$10$Hz.INcSPYSC66xc5C65jmuT4jFnVlZm0kyTTTheZnY0ilnZat0Y82', '2026-11-01 16:23:40', 0, 1),
(12, 4, '$2y$10$w/PNksRbT68Z3I1hFwfqV.0vSHzWmMScHxKi73ZKC.eyaGz5TKtUC', '2026-11-01 16:25:51', 0, 1),
(13, 5, '$2y$10$flZLLJosuNjn6ODPEsznnO7xQLrqOgodh9RaYML9lu8I58PHWmKTK', '2026-11-01 16:35:10', 0, 1),
(14, 1, '$2y$10$Q9f./gxtCMcDGwaISkE5JurG891vQ5v9NB22k327qNUbeAptFDC/y', '2026-11-01 16:36:11', 0, 1),
(15, 1, '$2y$10$n/y1Ks5gA6sGiRI5NIHSauUVcTJ3PVvvceReMHErrG.B7d3zE2QWC', '2026-11-01 17:08:52', 0, 1),
(16, 1, '$2y$10$3t3o963Hmni3DLrjspOcF.3xa884dWq3EfXrRlEYZnujQpkmF74HS', '2026-11-01 17:15:19', 0, 1),
(17, 1, '$2y$10$72N1QN9id1biF/A7LpI9bu8BDHWmoXbwAdeDsQq1lnvmhno2uvkiK', '2026-11-01 17:21:42', 0, 1),
(18, 1, '$2y$10$tAOCellrAaYAcifTFlkfcu62Lyozf2gx2yvFGdZz432N.4kk2Oi1e', '2026-11-01 17:30:06', 0, 1),
(19, 3, '$2y$10$s5o7ibFo2vRldPoJXQxbJuS1jJvoOJEvZ.z.Am1X7R7GwSjDbPHkS', '2026-11-01 17:35:56', 0, 1),
(20, 4, '$2y$10$eFQAeJIwJW3XUWWg3C/.WeY4jTo6Mt5lbKJ89w89hiUXIpA/Vic22', '2026-11-01 17:37:01', 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `reset_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `code_hash` varchar(255) NOT NULL,
  `expires_at` datetime NOT NULL,
  `is_used` tinyint(1) DEFAULT 0,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `password_resets`
--

INSERT INTO `password_resets` (`reset_id`, `user_id`, `code_hash`, `expires_at`, `is_used`, `created_at`) VALUES
(1, 2, '$2y$10$GC8AyjhFsD/tlYfc/yrxRevm2kv9FGw9kAIa1fpjYjvrFrz6Hki0q', '2026-11-01 15:52:45', 1, '2026-11-01 17:37:45');

-- --------------------------------------------------------

--
-- Table structure for table `stock_movements`
--

CREATE TABLE `stock_movements` (
  `movement_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `movement_date` date NOT NULL,
  `type` enum('in','out') NOT NULL,
  `reason` enum('sold','damaged','internal') DEFAULT NULL,
  `quantity` int(11) NOT NULL CHECK (`quantity` > 0),
  `unit_price` decimal(10,2) NOT NULL,
  `note` varchar(255) DEFAULT NULL,
  `recorded_by` int(11) NOT NULL,
  `is_edited` tinyint(1) DEFAULT 0,
  `edited_by` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `suppliers`
--

CREATE TABLE `suppliers` (
  `supplier_id` int(11) NOT NULL,
  `name` varchar(150) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `email` varchar(150) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `address` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `suppliers`
--

INSERT INTO `suppliers` (`supplier_id`, `name`, `phone`, `email`, `created_at`, `address`) VALUES
(2, 'Vapour Vapers LTD', '0712345678', 'vapour@co.ke', '2026-10-30 22:07:17', 'Nairobi West, Langata'),
(3, 'Safari Products Ltd', '0709876543', 'safari@gmail.com', '2026-10-30 22:09:53', 'Mombasa, Icolo nyali');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `email` varchar(150) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `role` enum('admin','staff') DEFAULT 'staff',
  `mfa_enabled` tinyint(1) DEFAULT 1,
  `is_active` tinyint(1) DEFAULT 1,
  `failed_attempts` int(11) DEFAULT 0,
  `locked_until` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `last_login` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `full_name`, `email`, `password_hash`, `role`, `mfa_enabled`, `is_active`, `failed_attempts`, `locked_until`, `created_at`, `last_login`) VALUES
(1, 'Linus Nzuki', 'linusnzuki3@gmail.com', '$2y$10$fEVpN5r8VzIkpBMk71KBHOl7YGCMXmbiMfvoxutJShfDTY77MxiOi', 'admin', 1, 1, 0, NULL, '2026-10-30 00:38:54', '2026-11-01 19:25:13'),
(2, 'John Doe', 'jd8543355@gmail.com', '$2y$10$b08/koooVwreh2MsjSSWFuWCqNO3xd1LpncWtIRJU1.HEqxvJ31i.', 'staff', 1, 1, 0, NULL, '2026-10-30 00:41:32', NULL),
(3, 'Sheel Patel', 'sheelpatel@strathmore.edu', '$2y$10$1cGUwiy5R7HoV7x.XrKbdu8gbyeF8Pq4xuoVCkFoQNaotyUzvPMY2', 'admin', 1, 1, 0, NULL, '2026-11-01 18:18:14', '2026-11-01 19:31:08'),
(4, 'Benedict Peter', 'benedictpeter@strathmore.edu', '$2y$10$7kM/BOuSRczkUY45vIsyCeUOZfAI.B.ACVaRS5R1wotorjETZpzJG', 'staff', 1, 1, 0, NULL, '2026-11-01 18:20:23', '2026-11-01 19:32:08'),
(5, 'Chantelle Kamau', 'chantellekamau@strathmore.edu', '$2y$10$WwNndLUEU73pFEpLRHHOpOLvM5Z606stlhxNb/6EerzdkMezn/TNG', 'staff', 1, 1, 0, NULL, '2026-11-01 18:29:50', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `audit_log`
--
ALTER TABLE `audit_log`
  ADD PRIMARY KEY (`log_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `company_profile`
--
ALTER TABLE `company_profile`
  ADD PRIMARY KEY (`profile_id`),
  ADD KEY `updated_by` (`updated_by`);

--
-- Indexes for table `items`
--
ALTER TABLE `items`
  ADD PRIMARY KEY (`item_id`),
  ADD UNIQUE KEY `sku` (`sku`),
  ADD KEY `supplier_id` (`supplier_id`);

--
-- Indexes for table `otp_codes`
--
ALTER TABLE `otp_codes`
  ADD PRIMARY KEY (`otp_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD PRIMARY KEY (`reset_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `stock_movements`
--
ALTER TABLE `stock_movements`
  ADD PRIMARY KEY (`movement_id`),
  ADD KEY `item_id` (`item_id`),
  ADD KEY `recorded_by` (`recorded_by`),
  ADD KEY `edited_by` (`edited_by`);

--
-- Indexes for table `suppliers`
--
ALTER TABLE `suppliers`
  ADD PRIMARY KEY (`supplier_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `audit_log`
--
ALTER TABLE `audit_log`
  MODIFY `log_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `items`
--
ALTER TABLE `items`
  MODIFY `item_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `otp_codes`
--
ALTER TABLE `otp_codes`
  MODIFY `otp_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `password_resets`
--
ALTER TABLE `password_resets`
  MODIFY `reset_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `stock_movements`
--
ALTER TABLE `stock_movements`
  MODIFY `movement_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `suppliers`
--
ALTER TABLE `suppliers`
  MODIFY `supplier_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `audit_log`
--
ALTER TABLE `audit_log`
  ADD CONSTRAINT `audit_log_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE SET NULL;

--
-- Constraints for table `company_profile`
--
ALTER TABLE `company_profile`
  ADD CONSTRAINT `company_profile_ibfk_1` FOREIGN KEY (`updated_by`) REFERENCES `users` (`user_id`);

--
-- Constraints for table `items`
--
ALTER TABLE `items`
  ADD CONSTRAINT `items_ibfk_1` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`supplier_id`) ON DELETE SET NULL;

--
-- Constraints for table `otp_codes`
--
ALTER TABLE `otp_codes`
  ADD CONSTRAINT `otp_codes_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD CONSTRAINT `password_resets_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `stock_movements`
--
ALTER TABLE `stock_movements`
  ADD CONSTRAINT `stock_movements_ibfk_1` FOREIGN KEY (`item_id`) REFERENCES `items` (`item_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `stock_movements_ibfk_2` FOREIGN KEY (`recorded_by`) REFERENCES `users` (`user_id`),
  ADD CONSTRAINT `stock_movements_ibfk_3` FOREIGN KEY (`edited_by`) REFERENCES `users` (`user_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
