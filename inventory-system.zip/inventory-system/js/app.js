/* ============================================================
   INVENTORY MANAGEMENT SYSTEM — app.js
   Communicates with PHP API. No localStorage data storage.
   ============================================================ */
(function () {
    "use strict";

    const API = "api/";

    const $  = (s, r = document) => r.querySelector(s);
    const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));
    const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({
        "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"
    }[c]));
    const money = (n) => Number(n || 0).toLocaleString(undefined, {
        minimumFractionDigits: 2, maximumFractionDigits: 2
    });
    const today = () => new Date().toISOString().slice(0, 10);
    const firstOfMonth = () => today().slice(0, 8) + "01";
    const debounce = (fn, ms = 300) => {
        let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); };
    };

    // Generic fetch helper
        // Generic fetch helper
    async function api(path, options = {}) {
        try {
            const res = await fetch(API + path, {
                credentials: "same-origin",
                headers: { "Content-Type": "application/json" },
                ...options
            });
            
            const text = await res.text(); // Get raw text first
            let data;
            try {
                data = JSON.parse(text); // Try to parse as JSON
            } catch (e) {
                // If it's not JSON, PHP probably threw an HTML error or fatal crash
                console.error("PHP Backend Error:", text);
                throw new Error("Server crashed. Check if MySQL is running. (See console F12)");
            }

            if (!res.ok) throw new Error(data.error || "Request failed");
            return data;
        } catch (err) {
            throw err;
        }
    }

    // Idle timeout (FR-014)
    let idleTimer = null;
    function resetIdle() {
        clearTimeout(idleTimer);
        idleTimer = setTimeout(async () => {
            await api("auth.php?action=logout", { method: "POST" });
            alert("Signed out after 30 minutes of inactivity.");
            location.href = "login.html";
        }, 30 * 60 * 1000);
    }
    ["click","keydown","mousemove","touchstart"].forEach((e) =>
        window.addEventListener(e, resetIdle));
    resetIdle();

    // ---- Utilities for tables ----
    function badgeFor(key, label) {
        return `<span class="status-badge status-${key}">${esc(label)}</span>`;
    }
    function emptyRow(cols, msg) {
        return `<tr class="empty-row"><td colspan="${cols}">${esc(msg)}</td></tr>`;
    }

    // ============================================================
    // AUTH — LOGIN
    // ============================================================
        // ============================================================
    // AUTH — LOGIN
    // ============================================================
    async function initLoginPage() {
        const form = $("#loginForm");
        if (!form) return;

        // --- ADDED SHOW PASSWORD LOGIC HERE ---
        const passwordInput = $("#password");
        const showPw = $("#showPassword");
        if (showPw && passwordInput) {
            showPw.addEventListener("change", () => {
                passwordInput.type = showPw.checked ? "text" : "password";
            });
        }
        // --------------------------------------

        form.addEventListener("submit", async (e) => {
            e.preventDefault();
            const email = $("#email").value.trim();
            const pw    = $("#password").value;
            const err = $("#loginError");
            err.textContent = "";
            try {
                const r = await api("auth.php?action=login", {
                    method: "POST",
                    body: JSON.stringify({ email, password: pw })
                });
                // MFA step
                if (r.demo_code) {
                    sessionStorage.setItem("demo_code", r.demo_code);
                }
                location.href = "verify.html";
            } catch (ex) {
                err.textContent = ex.message;
            }
        });
    }

    // ============================================================
    // AUTH — SIGNUP
    // ============================================================
    async function initSignupPage() {
        const form = $("#signupForm");
        if (!form) return;
        form.addEventListener("submit", async (e) => {
            e.preventDefault();
            const payload = {
                name: $("#fullname").value.trim(),
                role: $("#role").value,
                email: $("#email").value.trim(),
                password: $("#password").value,
                confirmPassword: $("#confirmPassword").value
            };
            const err = $("#signupError");
            err.textContent = "";
            if (payload.password !== payload.confirmPassword) {
                err.textContent = "Passwords do not match.";
                return;
            }
            try {
                const r = await api("auth.php?action=signup", {
                    method: "POST",
                    body: JSON.stringify(payload)
                });
                alert(r.success);
                location.href = "login.html";
            } catch (ex) {
                err.textContent = ex.message;
            }
        });
    }

        // ============================================================
    // AUTH — FORGOT PASSWORD
    // ============================================================
    async function initForgotPage() {
        const form = $("#forgotForm");
        if (!form) return;

        form.addEventListener("submit", async (e) => {
            e.preventDefault();
            const email = $("#email").value.trim();
            const err = $("#forgotError");
            err.textContent = "";

            try {
                const r = await api("auth.php?action=forgot", {
                    method: "POST",
                    body: JSON.stringify({ email })
                });
                
                // For testing locally, save the demo code and email
                sessionStorage.setItem("reset_email", email);
                if (r.demo_code) {
                    sessionStorage.setItem("reset_demo_code", r.demo_code);
                }
                
                // Redirect to reset screen
                location.href = "reset.html";
            } catch (ex) {
                err.textContent = ex.message;
            }
        });
    }

    // ============================================================
    // AUTH — RESET PASSWORD
    // ============================================================
    async function initResetPage() {
        const form = $("#resetForm");
        if (!form) return;

        const email = sessionStorage.getItem("reset_email");
        if (!email) {
            location.href = "forgot.html";
            return;
        }

        // Show demo code locally
        const demoCode = sessionStorage.getItem("reset_demo_code");
        if (demoCode) {
            const note = $("#resetCodeNote");
            if (note) note.textContent = `Test code: ${demoCode}`;
        }

        form.addEventListener("submit", async (e) => {
            e.preventDefault();
            const code = $("#resetCode").value.trim();
            const password = $("#newPassword").value;
            const confirm = $("#confirmPassword").value;
            const err = $("#resetError");
            err.textContent = "";

            if (password !== confirm) {
                err.textContent = "Passwords do not match.";
                return;
            }

            try {
                const r = await api("auth.php?action=reset", {
                    method: "POST",
                    body: JSON.stringify({ email, code, password })
                });
                
                sessionStorage.removeItem("reset_email");
                sessionStorage.removeItem("reset_demo_code");
                
                alert(r.success);
                location.href = "login.html";
            } catch (ex) {
                err.textContent = ex.message;
            }
        });
    }

    // ============================================================
    // AUTH — VERIFY MFA
    // ============================================================
    async function initVerifyPage() {
        const form = $("#verifyForm");
        if (!form) return;
        // Show demo code (only for testing — remove in production)
        const demoCode = sessionStorage.getItem("demo_code");
        if (demoCode) {
            const note = $("#demoCodeNote");
            if (note) note.textContent = `Test code: ${demoCode}`;
        }
        form.addEventListener("submit", async (e) => {
            e.preventDefault();
            const code = $("#otp").value.trim();
            const err = $("#verifyError");
            err.textContent = "";
            try {
                await api("auth.php?action=verify_mfa", {
                    method: "POST",
                    body: JSON.stringify({ code })
                });
                sessionStorage.removeItem("demo_code");
                location.href = "dashboard.html";
            } catch (ex) {
                err.textContent = ex.message;
            }
        });
        const resendBtn = $("#resendBtn");
if (resendBtn) {
    resendBtn.onclick = async () => {
        resendBtn.disabled = true;
        resendBtn.textContent = "Sending...";
        try {
            const r = await api("auth.php?action=resend_mfa", { method: "POST" });
            if (r.demo_code) {
                sessionStorage.setItem("demo_code", r.demo_code);
                const note = $("#demoCodeNote");
                if (note) note.textContent = `Test code: ${r.demo_code}`;
            }
            $("#resendNote").textContent = "New code sent.";
            // 60-second cooldown
            let wait = 60;
            resendBtn.textContent = `Resend in ${wait}s`;
            const timer = setInterval(() => {
                wait--;
                if (wait <= 0) {
                    clearInterval(timer);
                    resendBtn.disabled = false;
                    resendBtn.textContent = "Resend code";
                } else {
                    resendBtn.textContent = `Resend in ${wait}s`;
                }
            }, 1000);
        } catch (ex) {
            $("#resendNote").textContent = ex.message;
            resendBtn.disabled = false;
            resendBtn.textContent = "Resend code";
        }
    };
}
    }

    // ============================================================
    // REQUIRED AUTH GUARD
    // ============================================================
    async function requireAuth() {
        try {
            const r = await api("auth.php?action=session");
            return r.user;
        } catch {
            location.href = "login.html";
            return null;
        }
    }

    // ============================================================
    // DASHBOARD
    // ============================================================
    async function initDashboardPage() {
        const user = await requireAuth();
        if (!user) return;

        const items = await api("items.php");
        const recent = await api("movements.php?action=recent");
        const suppliers = await api("suppliers.php");

        const totalValue = items.reduce((s, i) => s + i.current_stock * i.unit_price, 0);
        const low = items.filter((i) => i.status.key !== "ok");

        $("#statItems").textContent = items.length;
        $("#statValue").textContent = money(totalValue);
        $("#statLow").textContent = low.length;
        $("#statSuppliers").textContent = suppliers.length;

        // Low stock table
        const lowBody = $("#lowStockTableBody");
        if (!low.length) {
            lowBody.innerHTML = emptyRow(6, "No items are below their minimum level.");
        } else {
            lowBody.innerHTML = low.map((i) => {
                const reorder = Math.max(i.min_stock * 2 - i.current_stock, 1);
                return `<tr>
                    <td>${esc(i.name)}</td>
                    <td class="num">${i.current_stock}</td>
                    <td class="num">${i.min_stock}</td>
                    <td class="num">${reorder}</td>
                    <td>${esc(i.supplier_name || "-")}</td>
                    <td>${badgeFor(i.status.key, i.status.label)}</td>
                </tr>`;
            }).join("");
        }

        // Recent movements
        const recBody = $("#recentMovementsBody");
        if (!recent.length) {
            recBody.innerHTML = emptyRow(6, "No stock movements yet.");
        } else {
            recBody.innerHTML = recent.map((t) => `<tr>
                <td>${esc(t.movement_date)}</td>
                <td>${esc(t.item_name)}</td>
                <td>${badgeFor(t.type === "in" ? "in" : "out",
                    t.type === "in" ? "Stock in" : (t.reason === "damaged" ? "Damaged" : "Stock out"))}</td>
                <td class="num">${t.quantity}</td>
                <td>${esc(t.note || "")}</td>
                <td>${esc(t.user_name || "")}</td>
            </tr>`).join("");
        }
    }

    // ============================================================
    // ITEMS
    // ============================================================
    async function initItemsPage() {
        const user = await requireAuth();
        if (!user) return;
        const items = await api("items.php");
        const tbody = $("#itemsTableBody");

        if (!items.length) {
            tbody.innerHTML = emptyRow(9, "No items found. Add your first item to start tracking stock.");
            return;
        }

        tbody.innerHTML = items.map((i) => `<tr>
            <td>${esc(i.sku)}</td>
            <td>${esc(i.name)}</td>
            <td>${esc(i.category || "")}</td>
            <td>${esc(i.supplier_name || "-")}</td>
            <td class="num">${money(i.unit_price)}</td>
            <td class="num">${i.current_stock}</td>
            <td class="num">${i.min_stock}</td>
            <td>${badgeFor(i.status.key, i.status.label)}</td>
            <td>
                <a class="action-btn" href="item-add.html?id=${i.item_id}">Edit</a>
                ${user.role === "admin"
                    ? `<button class="action-btn danger" data-del="${i.item_id}">Delete</button>`
                    : ""}
            </td>
        </tr>`).join("");

        $$("[data-del]", tbody).forEach((b) => {
            b.onclick = async () => {
                if (!confirm("Delete this item and its stock history?")) return;
                try {
                    await api(`items.php?action=delete&id=${b.dataset.del}`, { method: "POST" });
                    location.reload();
                } catch (ex) { alert(ex.message); }
            };
        });

        // Client-side search/filter
        const search = $("#search");
        const cat = $("#category");
        const st = $("#status");
        function filter() {
            const q = (search.value || "").toLowerCase();
            const c = cat.value, s = st.value;
            $$("#itemsTableBody tr").forEach((tr) => {
                const txt = tr.textContent.toLowerCase();
                const match = (!q || txt.includes(q)) &&
                              (!c || tr.children[2].textContent === c) &&
                              (!s || tr.querySelector(".status-badge").textContent.toLowerCase().includes(s === "ok" ? "in stock" : s === "low" ? "low" : "out"));
                tr.style.display = match ? "" : "none";
            });
        }
        search.oninput = debounce(filter, 200);
        cat.onchange = filter;
        st.onchange = filter;
    }

    // ============================================================
    // ITEM ADD / EDIT
    // ============================================================
    async function initItemFormPage() {
        const user = await requireAuth();
        if (!user) return;
        const params = new URLSearchParams(location.search);
        const editId = params.get("id");

        // Load suppliers for dropdown
        const sups = await api("suppliers.php");
        const supSel = $("#itemSupplier");
        supSel.innerHTML = `<option value="">None</option>` +
            sups.map((s) => `<option value="${s.supplier_id}">${esc(s.name)}</option>`).join("");

        if (editId) {
            const it = await api(`items.php?action=one&id=${editId}`);
            $("#itemFormTitle").textContent = "Edit Item";
            $("#itemId").value = it.item_id;
            $("#itemName").value = it.name;
            $("#itemSku").value = it.sku;
            $("#itemCategory").value = it.category || "";
            $("#itemPrice").value = it.unit_price;
            $("#itemMin").value = it.min_stock;
            if (it.supplier_id) supSel.value = it.supplier_id;
            $("#openingQtyGroup").hidden = true;
        }

        $("#itemForm").addEventListener("submit", async (e) => {
            e.preventDefault();
            const payload = {
                name: $("#itemName").value.trim(),
                sku: $("#itemSku").value.trim(),
                category: $("#itemCategory").value.trim(),
                supplier_id: supSel.value || null,
                price: parseFloat($("#itemPrice").value),
                min: parseInt($("#itemMin").value, 10),
                opening: parseInt($("#itemOpening").value || 0, 10)
            };
            const err = $("#itemFormError");
            err.textContent = "";
            try {
                if (editId) {
                    await api(`items.php?action=update&id=${editId}`, {
                        method: "POST",
                        body: JSON.stringify(payload)
                    });
                } else {
                    await api("items.php?action=create", {
                        method: "POST",
                        body: JSON.stringify(payload)
                    });
                }
                location.href = "items.html";
            } catch (ex) { err.textContent = ex.message; }
        });
    }

    // ============================================================
    // STOCK IN / OUT
    // ============================================================
    async function initStockPage() {
        const user = await requireAuth();
        if (!user) return;

        const items = await api("items.php");
        const sel = $("#stockItem");
        sel.innerHTML = `<option value="">Select an item</option>` +
            items.map((i) => `<option value="${i.item_id}">${esc(i.name)} (${i.current_stock} in stock)</option>`).join("");

        $("#stockDate").value = today();
        $("#stockDate").max = today();

        $("#stockType").onchange = () => {
            $("#stockReasonGroup").hidden = $("#stockType").value !== "out";
        };

        $("#stockForm").addEventListener("submit", async (e) => {
            e.preventDefault();
            const payload = {
                item_id: parseInt(sel.value, 10),
                date: $("#stockDate").value,
                type: $("#stockType").value,
                qty: parseInt($("#stockQty").value, 10),
                note: $("#stockNote").value.trim(),
                reason: $("#stockReason").value
            };
            const err = $("#stockFormError");
            err.textContent = "";
            try {
                await api("movements.php?action=record", {
                    method: "POST",
                    body: JSON.stringify(payload)
                });
                location.reload();
            } catch (ex) { err.textContent = ex.message; }
        });

        // Load full ledger
        const ledger = await api(`movements.php?action=ledger&item_id=0`).catch(() => []);
        // Note: we need to pick an item to show the ledger — keep it simple, show all
        const allMoves = await api("movements.php?action=recent").catch(() => []);
        const body = $("#ledgerTableBody");
        if (!allMoves.length) {
            body.innerHTML = emptyRow(9, "No stock movements yet.");
        } else {
            body.innerHTML = allMoves.map((t) => `<tr>
                <td>${esc(t.movement_date)}</td>
                <td>${esc(t.item_name)}</td>
                <td>${badgeFor(t.type === "in" ? "in" : "out", t.type === "in" ? "Stock in" : "Stock out")}</td>
                <td class="num">${t.type === "in" ? "+" + t.quantity : ""}</td>
                <td class="num">${t.type === "out" ? "-" + t.quantity : ""}</td>
                <td class="num"><strong>${t.balance ?? ""}</strong></td>
                <td>${esc(t.note || "")}</td>
                <td>${esc(t.user_name || "")}</td>
                <td>
                    ${user.role === "admin"
                        ? `<button class="action-btn danger" data-tx="${t.movement_id}">Delete</button>`
                        : ""}
                </td>
            </tr>`).join("");

            $$("[data-tx]", body).forEach((b) => {
                b.onclick = async () => {
                    if (!confirm("Delete this entry?")) return;
                    try {
                        await api(`movements.php?action=delete&id=${b.dataset.tx}`, { method: "POST" });
                        location.reload();
                    } catch (ex) { alert(ex.message); }
                };
            });
        }
    }

    // ============================================================
    // SALES
    // ============================================================
    async function initSalesPage() {
    const user = await requireAuth();
    if (!user) return;

    const items = await api("items.php");
    const sel = $("#salesItem");
    sel.innerHTML = `<option value="">All items</option>` +
        items.map((i) => `<option value="${i.item_id}">${esc(i.name)}</option>`).join("");

    $("#salesFrom").value = firstOfMonth();
    $("#salesTo").value   = today();

    async function load() {
        const from = $("#salesFrom").value;
        const to   = $("#salesTo").value;
        const itemId = sel.value;
        const q = new URLSearchParams({ from, to });
        if (itemId) q.set("item_id", itemId);

        const r = await api("sales.php?" + q.toString());

        $("#salesUnits").textContent      = r.totals.units;
        $("#salesAmount").textContent     = money(r.totals.amount);
        $("#salesCount").textContent      = r.totals.sales_count;
        $("#salesItemsCount").textContent = r.totals.items_sold;

        const body = $("#salesTableBody");
        if (!r.rows.length) {
            body.innerHTML = emptyRow(7, "No sales in this period.");
            return;
        }
        body.innerHTML = r.rows.map((t) => `<tr>
            <td>${esc(t.movement_date)}</td>
            <td>${esc(t.item_name)}</td>
            <td class="num">${t.quantity}</td>
            <td class="num">${money(t.unit_price)}</td>
            <td class="num">${money(t.quantity * t.unit_price)}</td>
            <td>${esc(t.note || "")}</td>
            <td>${esc(t.user_name || "")}</td>
        </tr>`).join("");
    }

    $("#salesFrom").onchange = load;
    $("#salesTo").onchange   = load;
    sel.onchange             = load;
    load();
}

    // ============================================================
    // DAMAGED
    // ============================================================
    async function initDamagedPage() {
        const user = await requireAuth();
        if (!user) return;

        const items = await api("items.php");
        const sel = $("#damagedItem");
        sel.innerHTML = `<option value="">Select an item</option>` +
            items.map((i) => `<option value="${i.item_id}">${esc(i.name)} (${i.current_stock} valid)</option>`).join("");

        $("#damagedDate").value = today();
        $("#damagedDate").max = today();

        $("#damagedForm").addEventListener("submit", async (e) => {
            e.preventDefault();
            const payload = {
                item_id: parseInt(sel.value, 10),
                date: $("#damagedDate").value,
                type: "out",
                reason: "damaged",
                qty: parseInt($("#damagedQty").value, 10),
                note: $("#damagedNote").value.trim()
            };
            try {
                await api("movements.php?action=record", { method: "POST", body: JSON.stringify(payload) });
                location.reload();
            } catch (ex) { $("#damagedFormError").textContent = ex.message; }
        });

        // Show damaged rows in table
        const recent = await api("movements.php?action=recent");
        const damaged = recent.filter((t) => t.reason === "damaged");
        const body = $("#damagedTableBody");
        if (!damaged.length) {
            body.innerHTML = emptyRow(7, "No damaged stock recorded.");
        } else {
            body.innerHTML = damaged.map((t) => `<tr>
                <td>${esc(t.movement_date)}</td>
                <td>${esc(t.item_name)}</td>
                <td class="num">${t.quantity}</td>
                <td class="num">${money(t.quantity * t.unit_price)}</td>
                <td>${esc(t.note || "")}</td>
                <td>${esc(t.user_name || "")}</td>
                <td></td>
            </tr>`).join("");
        }
    }

    // ============================================================
    // SUPPLIERS
    // ============================================================
    async function initSuppliersPage() {
        const user = await requireAuth();
        if (!user) return;

        async function load() {
            const sups = await api("suppliers.php");
            const body = $("#suppliersTableBody");
            if (!sups.length) {
                body.innerHTML = emptyRow(6, "No suppliers yet.");
                return;
            }
            body.innerHTML = sups.map((s) => `<tr>
                <td>${esc(s.name)}</td>
                <td>${esc(s.phone || "")}</td>
                <td>${esc(s.email || "")}</td>
                <td>${esc(s.address || "")}</td>
                <td class="num">${s.item_count}</td>
                <td>
                    ${user.role === "admin"
                        ? `<button class="action-btn danger" data-del="${s.supplier_id}">Delete</button>`
                        : ""}
                </td>
            </tr>`).join("");
            $$("[data-del]", body).forEach((b) => {
                b.onclick = async () => {
                    if (!confirm("Delete this supplier?")) return;
                    await api(`suppliers.php?action=delete&id=${b.dataset.del}`, { method: "POST" });
                    load();
                };
            });
        }

        $("#supplierForm").addEventListener("submit", async (e) => {
            e.preventDefault();
            const payload = {
                name: $("#supplierName").value.trim(),
                phone: $("#supplierPhone").value.trim(),
                email: $("#supplierEmail").value.trim(),
                address: $("#supplierAddress").value.trim()
            };
            try {
                await api("suppliers.php?action=create", { method: "POST", body: JSON.stringify(payload) });
                $("#supplierForm").reset();
                load();
            } catch (ex) { $("#supplierFormError").textContent = ex.message; }
        });

        load();
    }

    // ============================================================
    // REPORTS
    // ============================================================
    async function initReportsPage() {
        const user = await requireAuth();
        if (!user) return;

        $("#reportFrom").value = firstOfMonth();
        $("#reportTo").value = today();

        const items = await api("items.php");
        const checklist = $("#reportItemsChecklist");
        checklist.innerHTML = items.map((i) =>
            `<label><input type="checkbox" data-item="${i.item_id}" checked> ${esc(i.name)}</label>`
        ).join("");

        async function load() {
            const from = $("#reportFrom").value;
            const to = $("#reportTo").value;
            const selected = $$("#reportItemsChecklist input:checked").map((c) => c.dataset.item);
            if (!selected.length) {
                $("#reportTableBody").innerHTML = emptyRow(7, "Select at least one item.");
                return;
            }
            const r = await api(`reports.php?from=${from}&to=${to}&items=${selected.join(",")}`);
            const body = $("#reportTableBody");
            if (!r.rows.length) {
                body.innerHTML = emptyRow(7, "No data for the selected period.");
                return;
            }
            body.innerHTML = r.rows.map((row) => `<tr>
                <td>${esc(row.name)}</td>
                <td class="num">${row.opening}</td>
                <td class="num">${row.in_qty}</td>
                <td class="num">${row.sold_qty}</td>
                <td class="num">${row.dmg_qty}</td>
                <td class="num">${row.closing}</td>
                <td class="num">${money(row.value)}</td>
            </tr>`).join("") +
            `<tr><th>Total value</th><th></th><th></th><th></th><th></th><th></th><th class="num">${money(r.total_value)}</th></tr>`;
        }

        $("#reportFrom").onchange = load;
        $("#reportTo").onchange = load;
        $("#selectAllItemsBtn").onclick = () => {
            $$("#reportItemsChecklist input").forEach((c) => c.checked = true);
            load();
        };
        $("#clearAllItemsBtn").onclick = () => {
            $$("#reportItemsChecklist input").forEach((c) => c.checked = false);
            load();
        };

        // FR-054: CSV export
        $("#downloadExcelBtn").onclick = async () => {
            const from = $("#reportFrom").value;
            const to = $("#reportTo").value;
            const selected = $$("#reportItemsChecklist input:checked").map((c) => c.dataset.item);
            const r = await api(`reports.php?from=${from}&to=${to}&items=${selected.join(",")}`);
            const header = ["Item", "Opening", "In", "Sold", "Damaged", "Closing", "Value"];
            const csv = [
                header.join(","),
                ...r.rows.map((row) => [
                    `"${row.name}"`, row.opening, row.in_qty, row.sold_qty, row.dmg_qty, row.closing, row.value
                ].join(","))
            ].join("\n");
            const blob = new Blob([csv], { type: "text/csv" });
            const a = document.createElement("a");
            a.href = URL.createObjectURL(blob);
            a.download = `stock-report-${from}-${to}.csv`;
            a.click();
        };

        load();
    }

        // ============================================================
    // USERS
    // ============================================================
    async function initUsersPage() {
        const user = await requireAuth();
        if (!user || user.role !== "admin") {
            location.href = "dashboard.html";
            return;
        }
        const body = $("#usersTableBody");
        
                async function load() {
            const users = await api("users.php");
            body.innerHTML = users.map((u) => {
                const isActive = (u.is_active == 1 || u.is_active === true);
                const isSelf = (u.user_id === user.user_id); // Are we looking at our own account?
                
                return `<tr>
                    <td>${esc(u.full_name)} ${isSelf ? "<b>(You)</b>" : ""}</td>
                    <td>${esc(u.email)}</td>
                    <td>
                        ${isSelf 
                            ? "Administrator" // Cannot change own role
                            : `<select class="role-select" data-role="${u.user_id}">
                                <option value="staff" ${u.role === 'staff' ? 'selected' : ''}>Staff</option>
                                <option value="admin" ${u.role === 'admin' ? 'selected' : ''}>Administrator</option>
                               </select>`
                        }
                    </td>
                    <td>${isActive
                        ? `<span class="status-badge status-ok">Active</span>`
                        : `<span class="status-badge status-zero">Deactivated</span>`}</td>
                    <td>
                        ${isSelf 
                            ? `<span style="color:var(--ink-3); font-size:12px;">Cannot modify self</span>` 
                            : `<button class="action-btn ${isActive ? 'danger' : ''}" data-toggle="${u.user_id}">
                                ${isActive ? "Deactivate" : "Reactivate"}
                               </button>`
                        }
                    </td>
                </tr>`;
            }).join("");

            // Handle Role Changes
            $$("[data-role]", body).forEach(select => {
                select.onchange = async (e) => {
                    const newRole = e.target.value;
                    const userId = e.target.dataset.role;
                    if (!confirm(`Change this user's role to ${newRole === 'admin' ? 'Administrator' : 'Staff'}?`)) {
                        load(); // Revert if cancelled
                        return;
                    }
                    try {
                        await api(`users.php?action=role&id=${userId}`, { 
                            method: "POST", 
                            body: JSON.stringify({ role: newRole })
                        });
                        load();
                    } catch (err) {
                        alert(err.message);
                        load();
                    }
                };
            });

            // Handle Deactivation
            $$("[data-toggle]", body).forEach((b) => {
                b.onclick = async () => {
                    const isDeactivating = b.textContent.trim() === "Deactivate";
                    const msg = isDeactivating 
                        ? "Are you sure you want to deactivate this user?" 
                        : "Are you sure you want to reactivate this user?";
                    
                    if (!confirm(msg)) return;
                    
                    try {
                        await api(`users.php?action=toggle&id=${b.dataset.toggle}`, { method: "POST" });
                        load();
                    } catch (err) {
                        alert(err.message);
                    }
                };
            });
        }
        load();
    }
    

    // ============================================================
    // ACCOUNT — placeholder, backed by same users API
    // ============================================================
    async function initAccountPage() {
        const user = await requireAuth();
        if (!user) return;
        $("#accountName").value = user.full_name;
        $("#accountEmail").value = user.email || "";
        $("#accountRole").value = user.role === "admin" ? "Administrator" : "Staff";
    }

    // ============================================================
    // COMPANY
    // ============================================================
    async function initCompanyPage() {
        const user = await requireAuth();
        if (!user || user.role !== "admin") {
            location.href = "dashboard.html";
            return;
        }
        const c = await api("company.php");
        $("#companyName").value = c.company_name || "";
        $("#companyPhone").value = c.phone || "";
        $("#companyEmail").value = c.email || "";
        $("#companyHours").value = c.opening_hours || "";
        $("#companyAddress").value = c.address || "";
        $("#companyDescription").value = c.description || "";
        $("#companyMission").value = c.mission || "";
        $("#companyServices").value = c.services || "";

        $("#companyForm").addEventListener("submit", async (e) => {
            e.preventDefault();
            const payload = {
                company_name: $("#companyName").value.trim(),
                phone: $("#companyPhone").value.trim(),
                email: $("#companyEmail").value.trim(),
                opening_hours: $("#companyHours").value.trim(),
                address: $("#companyAddress").value.trim(),
                description: $("#companyDescription").value.trim(),
                mission: $("#companyMission").value.trim(),
                services: $("#companyServices").value.trim(),
                logo_path: ""
            };
            try {
                await api("company.php?action=update", { method: "POST", body: JSON.stringify(payload) });
                $("#companyFormError").textContent = "Profile saved.";
                $("#companyFormError").style.color = "var(--ok)";
            } catch (ex) { $("#companyFormError").textContent = ex.message; }
        });
    }

    // ============================================================
    // PUBLIC COMPANY PROFILE (index.html)
    // ============================================================
    async function initPublicPage() {
        try {
            const c = await api("company.php");
            document.title = `${c.company_name || "Inventory System"} | Welcome`;
            const nameEl = $("#pubCompanyName");
            if (nameEl) nameEl.textContent = c.company_name || "Inventory System";
            const descEl = $("#pubDescription");
            if (descEl) descEl.textContent = c.description || "Your inventory, under control.";
            const missionEl = $("#pubMission");
            if (missionEl && c.mission) missionEl.textContent = c.mission;
            const servicesEl = $("#pubServices");
            if (servicesEl && c.services) {
                servicesEl.innerHTML = c.services.split(/\n|,/).filter(Boolean)
                    .map((s) => `<li>${esc(s.trim())}</li>`).join("");
            }
            const addrEl = $("#pubAddress");
            if (addrEl) addrEl.textContent = c.address || "";
            const phoneEl = $("#pubPhone");
            if (phoneEl) phoneEl.textContent = c.phone || "";
            const emailEl = $("#pubEmail");
            if (emailEl) emailEl.textContent = c.email || "";
            const hoursEl = $("#pubHours");
            if (hoursEl) hoursEl.textContent = c.opening_hours || "";
        } catch (ex) {
            console.warn("Company profile unavailable:", ex.message);
        }
    }

    // ============================================================
    // BOOT
    // ============================================================
    const PAGE_INIT = {
        "login.html":     initLoginPage,
        "signup.html":    initSignupPage,
        "forgot.html":    initForgotPage,
        "reset.html":     initResetPage,
        "verify.html":    initVerifyPage,
        "index.html":     initPublicPage,
        "dashboard.html": initDashboardPage,
        "items.html":     initItemsPage,
        "item-add.html":  initItemFormPage,
        "stock.html":     initStockPage,
        "sales.html":     initSalesPage,
        "damaged.html":   initDamagedPage,
        "suppliers.html": initSuppliersPage,
        "reports.html":   initReportsPage,
        "users.html":     initUsersPage,
        "account.html":   initAccountPage,
        "company.html":   initCompanyPage
    };

    document.addEventListener("DOMContentLoaded", () => {
        // Mark active nav
        const current = location.pathname.split("/").pop() || "dashboard.html";
        $$(".nav-links a").forEach((a) => {
            if (a.getAttribute("href") === current) a.classList.add("active");
        });
        // Top button
        const top = $("#topBtn");
        if (top) {
            window.addEventListener("scroll", () => {
                top.style.display = window.scrollY > 300 ? "grid" : "none";
            });
            top.onclick = () => window.scrollTo({ top: 0, behavior: "smooth" });
        }
        // Hide Admin-only links for Staff users
        api("auth.php?action=session").then(r => {
            if (r.user && r.user.role !== "admin") {
                // Find the links pointing to users.html and company.html and hide them
                $$(".nav-links a").forEach((a) => {
                    if (a.getAttribute("href") === "users.html" || a.getAttribute("href") === "company.html") {
                        a.style.display = "none";
                    }
                });
            }
        }).catch(() => {});
        const init = PAGE_INIT[current];
        if (init) init();
    });
})();