/* ============================================================
   INVENTORY MANAGEMENT SYSTEM — script.js
   Single-file logic for all 13 pages.
   Detects the current page by filename and initializes
   only the modules that page needs.
   ============================================================ */

(function () {
    "use strict";

    /* ============================================================
       0. CONSTANTS + STORAGE KEYS
       ============================================================ */
    const PREFIX = "ims_";
    const KEYS = {
        items:    PREFIX + "items",
        sups:     PREFIX + "sups",
        txs:      PREFIX + "txs",
        users:    PREFIX + "users",
        company:  PREFIX + "company",
        session:  PREFIX + "session"
    };

    /* ============================================================
       1. UTILITIES
       ============================================================ */
    const $  = (sel, root = document) => root.querySelector(sel);
    const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));

    const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({
        "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
    }[c]));

    const uid = () => Math.random().toString(36).slice(2, 9);

    const today = () => new Date().toISOString().slice(0, 10);

    const firstOfMonth = () => today().slice(0, 8) + "01";

    const money = (n) => Number(n || 0).toLocaleString(undefined, {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
    });

    const debounce = (fn, ms = 300) => {
        let t;
        return (...args) => {
            clearTimeout(t);
            t = setTimeout(() => fn(...args), ms);
        };
    };

    /* ============================================================
       2. STORAGE (localStorage wrapper)
       ============================================================ */
    const store = {
        get(key, fallback) {
            try {
                const raw = localStorage.getItem(key);
                return raw ? JSON.parse(raw) : fallback;
            } catch {
                return fallback;
            }
        },
        set(key, value) {
            try {
                localStorage.setItem(key, JSON.stringify(value));
            } catch (e) {
                console.error("Storage write failed:", e);
            }
        }
    };

    /* ============================================================
       3. DATA STATE
       ============================================================ */
    const D = {
        items:   store.get(KEYS.items, []),
        sups:    store.get(KEYS.sups, []),
        txs:     store.get(KEYS.txs, []),
        users:   store.get(KEYS.users, []),
        company: store.get(KEYS.company, {
            name: "", logo: "", description: "", mission: "",
            services: "", address: "", phone: "", email: "", hours: ""
        })
    };

    let me = store.get(KEYS.session, null);

    const save = () => {
        store.set(KEYS.items, D.items);
        store.set(KEYS.sups, D.sups);
        store.set(KEYS.txs, D.txs);
        store.set(KEYS.users, D.users);
        store.set(KEYS.company, D.company);
    };

    /* ============================================================
       4. DOMAIN HELPERS
       ============================================================ */
    const findItem = (id) => D.items.find((i) => i.id === id);
    const findSup  = (id) => D.sups.find((s) => s.id === id);

    const stock = (id) => D.txs
        .filter((t) => t.itemId === id)
        .reduce((s, t) => s + (t.type === "in" ? t.qty : -t.qty), 0);

    const statusOf = (item) => {
        const q = stock(item.id);
        if (q <= 0)         return { key: "zero", label: "Out of stock" };
        if (q <= item.min)  return { key: "low",  label: "Low stock" };
        return { key: "ok", label: "In stock" };
    };

    const isSale = (t) => t.type === "out" && (t.reason || "sold") === "sold";
    const isDmg  = (t) => t.type === "out" && t.reason === "damaged";

    const amountOf = (t) => t.qty * (t.price ?? findItem(t.itemId)?.price ?? 0);

    const sumTxs = (list) => ({
        qty:    list.reduce((n, t) => n + t.qty, 0),
        amount: list.reduce((n, t) => n + amountOf(t), 0)
    });

    const lowCount = () => D.items.filter((i) => statusOf(i).key !== "ok").length;

    const damagedQty = (id) => D.txs
        .filter((t) => t.itemId === id && isDmg(t))
        .reduce((n, t) => n + t.qty, 0);

    /* ============================================================
       5. PASSWORD HASHING
       ============================================================ */
    async function hashPassword(password) {
        try {
            const buf = await crypto.subtle.digest(
                "SHA-256",
                new TextEncoder().encode(password)
            );
            return Array.from(new Uint8Array(buf))
                .map((b) => b.toString(16).padStart(2, "0"))
                .join("");
        } catch {
            return btoa(password);
        }
    }

    /* ============================================================
       6. NAV HELPERS
       ============================================================ */
    function markActiveNav() {
        const current = location.pathname.split("/").pop() || "dashboard.html";
        $$(".nav-links a").forEach((a) => {
            const href = a.getAttribute("href");
            a.classList.toggle("active", href === current);
        });
    }

    function requireAuth() {
        if (!me) {
            location.href = "login.html";
            return false;
        }
        return true;
    }

    function requireAdmin() {
        if (!requireAuth()) return false;
        if (me.role !== "admin") {
            location.href = "dashboard.html";
            return false;
        }
        return true;
    }

    function initSignOutLink() {
        const link = $('.nav-signout');
        if (!link) return;
        link.addEventListener("click", (e) => {
            e.preventDefault();
            if (!confirm("Sign out now?")) return;
            me = null;
            store.set(KEYS.session, null);
            location.href = "login.html";
        });
    }

    function initTopButton() {
        const btn = $("#topBtn");
        if (!btn) return;
        window.addEventListener("scroll", () => {
            btn.style.display = window.scrollY > 300 ? "grid" : "none";
            btn.style.placeItems = "center";
        });
        btn.addEventListener("click", () => {
            window.scrollTo({ top: 0, behavior: "smooth" });
        });
    }

    /* ============================================================
       7. SHARED RENDER HELPERS
       ============================================================ */
    function badgeFor(statusKey, label) {
        return `<span class="status-badge status-${statusKey}">${esc(label)}</span>`;
    }

    function emptyRow(colspan, message) {
        return `<tr class="empty-row"><td colspan="${colspan}">${esc(message)}</td></tr>`;
    }

    function populateSelect(selectEl, list, { placeholder, getValue, getLabel, selected } = {}) {
        if (!selectEl) return;
        selectEl.innerHTML = "";
        if (placeholder) {
            const opt = document.createElement("option");
            opt.value = "";
            opt.textContent = placeholder;
            selectEl.appendChild(opt);
        }
        list.forEach((entry) => {
            const opt = document.createElement("option");
            opt.value = getValue(entry);
            opt.textContent = getLabel(entry);
            if (selected != null && opt.value === String(selected)) opt.selected = true;
            selectEl.appendChild(opt);
        });
    }

    function optionsForItems(items, includeStock = true) {
        return items.map((i) => ({
            id: i.id,
            label: includeStock ? `${i.name} (${stock(i.id)} in stock)` : i.name
        }));
    }

    /* ============================================================
       8. PAGE: LOGIN
       ============================================================ */
    function initLoginPage() {
        const form = $("#loginForm");
        if (!form) return;

        const emailInput = $("#email");
        const passwordInput = $("#password");
        const showPw = $("#showPassword");
        const errorEl = $("#loginError");

        if (showPw) {
            showPw.addEventListener("change", () => {
                passwordInput.type = showPw.checked ? "text" : "password";
            });
        }

        form.addEventListener("submit", async (e) => {
            e.preventDefault();
            errorEl.textContent = "";

            const email = emailInput.value.trim().toLowerCase();
            const pw = passwordInput.value;

            const user = D.users.find((u) => u.email === email);
            if (!user) {
                errorEl.textContent = "No account found with this email. Create an account first.";
                return;
            }
            if (user.active === false) {
                errorEl.textContent = "This account has been deactivated. Contact the administrator.";
                return;
            }

            const hashed = await hashPassword(pw);
            if (user.pass !== hashed) {
                errorEl.textContent = "Incorrect password. Please try again.";
                return;
            }

            me = { id: user.id, name: user.name, role: user.role };
            store.set(KEYS.session, me);
            location.href = "dashboard.html";
        });
    }

    /* ============================================================
       9. PAGE: SIGNUP
       ============================================================ */
    function initSignupPage() {
        const form = $("#signupForm");
        if (!form) return;

        const nameInput     = $("#fullname");
        const roleInput     = $("#role");
        const emailInput    = $("#email");
        const passwordInput = $("#password");
        const confirmInput  = $("#confirmPassword");
        const errorEl       = $("#signupError");

        // Hide admin option if one already exists
        const adminExists = D.users.some((u) => u.role === "admin");
        if (adminExists) {
            const adminOpt = Array.from(roleInput.options).find((o) => o.value === "admin");
            if (adminOpt) {
                adminOpt.disabled = true;
                adminOpt.textContent = "Administrator (already taken)";
                roleInput.value = "staff";
            }
        }

        form.addEventListener("submit", async (e) => {
            e.preventDefault();
            errorEl.textContent = "";

            const name  = nameInput.value.trim();
            const role  = roleInput.value;
            const email = emailInput.value.trim().toLowerCase();
            const pw    = passwordInput.value;
            const pw2   = confirmInput.value;

            if (name.length < 2) {
                errorEl.textContent = "Please enter your full name.";
                return;
            }
            if (role === "admin" && adminExists) {
                errorEl.textContent = "An administrator already exists. Create a staff account.";
                return;
            }
            if (!/^[^@\s]+@[^@\s]+\.[A-Za-z]{2,}$/.test(email)) {
                errorEl.textContent = "Please enter a valid email address.";
                return;
            }
            if (D.users.some((u) => u.email === email)) {
                errorEl.textContent = "An account with this email already exists. Sign in instead.";
                return;
            }
            if (!/^(?=.*[A-Za-z])(?=.*\d).{8,}$/.test(pw)) {
                errorEl.textContent = "Password must be at least 8 characters and contain letters and numbers.";
                return;
            }
            if (pw !== pw2) {
                errorEl.textContent = "The passwords do not match.";
                return;
            }

            const hashed = await hashPassword(pw);
            const user = {
                id: uid(),
                name,
                email,
                pass: hashed,
                role,
                active: true,
                createdAt: new Date().toISOString()
            };
            D.users.push(user);
            save();

            me = { id: user.id, name: user.name, role: user.role };
            store.set(KEYS.session, me);
            location.href = "dashboard.html";
        });
    }

    /* ============================================================
       10. PAGE: DASHBOARD
       ============================================================ */
    function initDashboardPage() {
        if (!requireAuth()) return;

        // Stats
        const totalValue = D.items.reduce((s, i) => s + stock(i.id) * i.price, 0);
        const totalDamaged = D.txs.filter(isDmg).reduce((n, t) => n + t.qty, 0);

        $("#statItems").textContent = D.items.length;
        $("#statValue").textContent = money(totalValue);
        $("#statLow").textContent = lowCount();
        $("#statSuppliers").textContent = D.sups.length;
        $("#statDamaged").textContent = totalDamaged;

        // Low-stock table
        const lowItems = D.items.filter((i) => statusOf(i).key !== "ok");
        const lowBody = $("#lowStockTableBody");
        if (lowItems.length === 0) {
            lowBody.innerHTML = emptyRow(6, "No items are below their minimum level.");
        } else {
            lowBody.innerHTML = lowItems.map((i) => {
                const q = stock(i.id);
                const st = statusOf(i);
                const reorder = Math.max(i.min * 2 - q, 1);
                return `
                    <tr>
                        <td>${esc(i.name)}</td>
                        <td class="num">${q}</td>
                        <td class="num">${i.min}</td>
                        <td class="num">${reorder}</td>
                        <td>${esc(findSup(i.supId)?.name || "-")}</td>
                        <td>${badgeFor(st.key, st.label)}</td>
                    </tr>`;
            }).join("");
        }

        // Stock levels bar chart
        const levelsBox = $("#stockLevels");
        if (D.items.length === 0) {
            levelsBox.innerHTML = `<p class="empty-row">Add items to see stock levels.</p>`;
        } else {
            const top = [...D.items]
                .sort((a, b) => stock(b.id) - stock(a.id))
                .slice(0, 8);
            const max = Math.max(1, ...top.map((i) => stock(i.id)));
            levelsBox.innerHTML = top.map((i) => {
                const q = stock(i.id);
                const st = statusOf(i);
                const pct = Math.max(0, q) / max * 100;
                return `
                    <div class="stock-level-row">
                        <span>${esc(i.name)}</span>
                        <div class="stock-level-bar"><i class="${st.key}" style="width:${pct}%"></i></div>
                        <span class="stock-level-count">${q}</span>
                    </div>`;
            }).join("");
        }

        // Recent movements
        const recent = [...D.txs]
            .sort((a, b) => b.date.localeCompare(a.date))
            .slice(0, 5);
        const recentBody = $("#recentMovementsBody");
        if (recent.length === 0) {
            recentBody.innerHTML = emptyRow(6, "No stock movements yet.");
        } else {
            recentBody.innerHTML = recent.map((t) => {
                const label = t.type === "in" ? "Stock in"
                             : t.reason === "damaged" ? "Damaged"
                             : "Stock out";
                const cls = t.type === "in" ? "in" : "out";
                return `
                    <tr>
                        <td>${esc(t.date)}</td>
                        <td>${esc(findItem(t.itemId)?.name || "(deleted)")}</td>
                        <td>${badgeFor(cls, label)}</td>
                        <td class="num">${t.qty}</td>
                        <td>${esc(t.note || "")}</td>
                        <td>${esc(t.user || "")}</td>
                    </tr>`;
            }).join("");
        }
    }

    /* ============================================================
       11. PAGE: ITEMS
       ============================================================ */
    function initItemsPage() {
        if (!requireAuth()) return;

        const searchEl   = $("#search");
        const categoryEl = $("#category");
        const statusEl   = $("#status");
        const tbody      = $("#itemsTableBody");

        // Populate categories
        const categories = [...new Set(D.items.map((i) => i.category).filter(Boolean))];
        populateSelect(categoryEl, categories.map((c) => ({ c })), {
            placeholder: "All categories",
            getValue: (x) => x.c,
            getLabel: (x) => x.c
        });

        function render() {
            const q   = (searchEl.value || "").trim().toLowerCase();
            const cat = categoryEl.value;
            const st  = statusEl.value;

            const filtered = D.items.filter((i) => {
                const hay = `${i.name} ${i.sku} ${i.category || ""}`.toLowerCase();
                if (q && !hay.includes(q)) return false;
                if (cat && i.category !== cat) return false;
                if (st && statusOf(i).key !== st) return false;
                return true;
            });

            if (filtered.length === 0) {
                tbody.innerHTML = emptyRow(9, "No items found. Add your first item to start tracking stock.");
                return;
            }

            tbody.innerHTML = filtered.map((i) => {
                const s = statusOf(i);
                const isAdmin = me.role === "admin";
                return `
                    <tr>
                        <td>${esc(i.sku)}</td>
                        <td>${esc(i.name)}</td>
                        <td>${esc(i.category || "")}</td>
                        <td>${esc(findSup(i.supId)?.name || "-")}</td>
                        <td class="num">${money(i.price)}</td>
                        <td class="num">${stock(i.id)}</td>
                        <td class="num">${i.min}</td>
                        <td>${badgeFor(s.key, s.label)}</td>
                        <td>
                            <button class="action-btn" data-edit="${i.id}">Edit</button>
                            ${isAdmin ? `<button class="action-btn danger" data-delete="${i.id}">Delete</button>` : ""}
                        </td>
                    </tr>`;
            }).join("");

            $$("[data-edit]", tbody).forEach((btn) => {
                btn.onclick = () => {
                    location.href = `item-add.html?id=${btn.dataset.edit}`;
                };
            });
            $$("[data-delete]", tbody).forEach((btn) => {
                btn.onclick = () => {
                    const id = btn.dataset.delete;
                    const it = findItem(id);
                    if (!confirm(`Delete "${it.name}" and its entire stock history?`)) return;
                    D.items = D.items.filter((i) => i.id !== id);
                    D.txs = D.txs.filter((t) => t.itemId !== id);
                    save();
                    render();
                };
            });
        }

        searchEl.addEventListener("input", debounce(render, 200));
        categoryEl.addEventListener("change", render);
        statusEl.addEventListener("change", render);

        render();
    }

    /* ============================================================
       12. PAGE: ITEM ADD / EDIT
       ============================================================ */
    function initItemFormPage() {
        if (!requireAuth()) return;

        const params    = new URLSearchParams(location.search);
        const editId    = params.get("id");
        const existing  = editId ? findItem(editId) : null;

        const titleEl   = $("#itemFormTitle");
        const form      = $("#itemForm");
        const errorEl   = $("#itemFormError");
        const openGroup = $("#openingQtyGroup");

        if (existing) {
            titleEl.textContent = "Edit Item";
            $("#itemId").value        = existing.id;
            $("#itemName").value      = existing.name;
            $("#itemSku").value       = existing.sku;
            $("#itemCategory").value  = existing.category || "";
            $("#itemPrice").value     = existing.price;
            $("#itemMin").value       = existing.min;
            openGroup.hidden = true;
        } else {
            openGroup.hidden = false;
        }

        // Populate suppliers
        populateSelect($("#itemSupplier"), D.sups, {
            placeholder: "None",
            getValue: (s) => s.id,
            getLabel: (s) => s.name,
            selected: existing?.supId || ""
        });

        form.addEventListener("submit", (e) => {
            e.preventDefault();
            errorEl.textContent = "";

            const f = {
                name:     $("#itemName").value.trim(),
                sku:      $("#itemSku").value.trim(),
                category: $("#itemCategory").value.trim(),
                supId:    $("#itemSupplier").value,
                price:    parseFloat($("#itemPrice").value),
                min:      parseInt($("#itemMin").value, 10)
            };

            if (!f.name)  return void (errorEl.textContent = "Name is required.");
            if (!f.sku)   return void (errorEl.textContent = "SKU is required.");
            if (!isFinite(f.price) || f.price < 0) return void (errorEl.textContent = "Price must be a non-negative number.");
            if (!isFinite(f.min) || f.min < 0) return void (errorEl.textContent = "Minimum stock must be a non-negative number.");

            const skuTaken = D.items.some((i) => i.sku === f.sku && i.id !== existing?.id);
            if (skuTaken) return void (errorEl.textContent = `SKU "${f.sku}" is already used by another item.`);

            if (existing) {
                Object.assign(existing, f);
            } else {
                const newItem = { id: uid(), ...f };
                D.items.push(newItem);
                const opening = parseInt($("#itemOpening").value, 10) || 0;
                if (opening > 0) {
                    D.txs.push({
                        id: uid(),
                        date: today(),
                        itemId: newItem.id,
                        type: "in",
                        qty: opening,
                        note: "Opening stock",
                        user: me.name
                    });
                }
            }

            save();
            location.href = "items.html";
        });
    }

    /* ============================================================
       13. PAGE: STOCK IN / OUT
       ============================================================ */
    function initStockPage() {
        if (!requireAuth()) return;

        const itemSelect   = $("#stockItem");
        const typeSelect   = $("#stockType");
        const reasonGroup  = $("#stockReasonGroup");
        const form         = $("#stockForm");
        const errorEl      = $("#stockFormError");
        const dateInput    = $("#stockDate");
        const ledgerBody   = $("#ledgerTableBody");

        dateInput.value = today();
        dateInput.max   = today();

        populateSelect(itemSelect, D.items, {
            placeholder: "Select an item",
            getValue: (i) => i.id,
            getLabel: (i) => `${i.name} (${stock(i.id)} in stock)`
        });

        typeSelect.addEventListener("change", () => {
            reasonGroup.hidden = typeSelect.value !== "out";
        });

        form.addEventListener("submit", (e) => {
            e.preventDefault();
            errorEl.textContent = "";

            const itemId = itemSelect.value;
            const type   = typeSelect.value;
            const qty    = parseInt($("#stockQty").value, 10);
            const date   = dateInput.value;
            const note   = $("#stockNote").value.trim();
            const reason = $("#stockReason").value;

            if (!itemId)          return void (errorEl.textContent = "Please select an item.");
            if (!isFinite(qty) || qty <= 0) return void (errorEl.textContent = "Quantity must be a positive number.");
            if (!date)            return void (errorEl.textContent = "Please choose a date.");
            if (date > today())   return void (errorEl.textContent = "Date cannot be in the future.");

            if (type === "out" && qty > stock(itemId)) {
                return void (errorEl.textContent = `Only ${stock(itemId)} of this item is in stock.`);
            }

            D.txs.push({
                id: uid(),
                date,
                itemId,
                type,
                qty,
                note,
                user: me.name,
                reason: type === "out" ? reason : undefined,
                price: findItem(itemId).price
            });
            save();
            renderLedger();
            form.reset();
            dateInput.value = today();
            reasonGroup.hidden = true;
        });

        function renderLedger() {
            const sorted = [...D.txs].sort((a, b) => a.date.localeCompare(b.date));

            // running balance per item
            const running = {};
            const withBalance = sorted.map((t) => {
                running[t.itemId] = (running[t.itemId] || 0) + (t.type === "in" ? t.qty : -t.qty);
                return { ...t, balance: running[t.itemId] };
            }).reverse();

            if (withBalance.length === 0) {
                ledgerBody.innerHTML = emptyRow(9, "No stock movements yet. Record the first one above.");
                return;
            }

            ledgerBody.innerHTML = withBalance.map((t) => {
                const it = findItem(t.itemId);
                const typeLabel = t.type === "in" ? "Stock in" : "Stock out";
                const badgeCls  = t.type === "in" ? "in" : "out";
                return `
                    <tr>
                        <td>${esc(t.date)}</td>
                        <td>${esc(it?.name || "(deleted)")}</td>
                        <td>${badgeFor(badgeCls, typeLabel)}</td>
                        <td class="num">${t.type === "in" ? "+" + t.qty : ""}</td>
                        <td class="num">${t.type === "out" ? "-" + t.qty : ""}</td>
                        <td class="num"><strong>${t.balance}</strong></td>
                        <td>${esc(t.note || "")}</td>
                        <td>${esc(t.user || "")}</td>
                        <td><button class="action-btn" data-tx="${t.id}">Edit</button></td>
                    </tr>`;
            }).join("");

            $$("[data-tx]", ledgerBody).forEach((btn) => {
                btn.onclick = () => editTx(btn.dataset.tx);
            });
        }

        function editTx(txId) {
            const tx = D.txs.find((t) => t.id === txId);
            if (!tx) return;

            const newQty = prompt(`New quantity (current: ${tx.qty}):`, tx.qty);
            if (newQty === null) return;
            const qty = parseInt(newQty, 10);
            if (!isFinite(qty) || qty <= 0) return alert("Please enter a positive number.");

            const newNote = prompt("Note:", tx.note || "");
            if (newNote === null) return;

            const updated = { ...tx, qty, note: newNote.trim(), edited: true, editedBy: me.name };

            // Validate balance never goes negative
            const test = D.txs.map((t) => (t.id === txId ? updated : t));
            const running = {};
            const ok = [...test]
                .sort((a, b) => a.date.localeCompare(b.date))
                .every((t) => {
                    running[t.itemId] = (running[t.itemId] || 0) + (t.type === "in" ? t.qty : -t.qty);
                    return running[t.itemId] >= 0;
                });

            if (!ok) return alert("This edit would make a stock balance go negative at a later date. Fix the later entries first.");

            D.txs = test;
            save();
            renderLedger();
        }

        renderLedger();
    }

    /* ============================================================
       14. PAGE: SALES
       ============================================================ */
    function initSalesPage() {
        if (!requireAuth()) return;

        const fromEl = $("#salesFrom");
        const toEl   = $("#salesTo");
        const itemEl = $("#salesItem");
        const tbody  = $("#salesTableBody");

        fromEl.value = firstOfMonth();
        toEl.value   = today();

        populateSelect(itemEl, D.items, {
            placeholder: "All items",
            getValue: (i) => i.id,
            getLabel: (i) => i.name
        });

        function render() {
            const from = fromEl.value;
            const to   = toEl.value;
            const itemId = itemEl.value;

            let sales = D.txs.filter((t) =>
                isSale(t) &&
                t.date >= from &&
                t.date <= to &&
                (!itemId || t.itemId === itemId)
            );

            const summary = sumTxs(sales);
            const uniqueItems = new Set(sales.map((t) => t.itemId)).size;

            $("#salesUnits").textContent = summary.qty;
            $("#salesAmount").textContent = money(summary.amount);
            $("#salesCount").textContent = sales.length;
            $("#salesItemsCount").textContent = uniqueItems;

            if (sales.length === 0) {
                tbody.innerHTML = emptyRow(7, "No sales in this period.");
                return;
            }

            tbody.innerHTML = sales
                .sort((a, b) => b.date.localeCompare(a.date))
                .map((t) => {
                    const it = findItem(t.itemId);
                    return `
                        <tr>
                            <td>${esc(t.date)}</td>
                            <td>${esc(it?.name || "(deleted)")}</td>
                            <td class="num">${t.qty}</td>
                            <td class="num">${money(t.price ?? it?.price ?? 0)}</td>
                            <td class="num">${money(amountOf(t))}</td>
                            <td>${esc(t.note || "")}</td>
                            <td>${esc(t.user || "")}</td>
                        </tr>`;
                }).join("");
        }

        fromEl.addEventListener("change", render);
        toEl.addEventListener("change", render);
        itemEl.addEventListener("change", render);
        render();
    }

    /* ============================================================
       15. PAGE: DAMAGED STOCK
       ============================================================ */
    function initDamagedPage() {
        if (!requireAuth()) return;

        const form       = $("#damagedForm");
        const errorEl    = $("#damagedFormError");
        const itemSel    = $("#damagedItem");
        const dateInput  = $("#damagedDate");
        const fromEl     = $("#damagedFrom");
        const toEl       = $("#damagedTo");
        const itemFilter = $("#damagedItemFilter");
        const tbody      = $("#damagedTableBody");

        dateInput.value = today();
        dateInput.max   = today();
        fromEl.value    = firstOfMonth();
        toEl.value      = today();

        populateSelect(itemSel, D.items, {
            placeholder: "Select an item",
            getValue: (i) => i.id,
            getLabel: (i) => `${i.name} (${stock(i.id)} valid)`
        });
        populateSelect(itemFilter, D.items, {
            placeholder: "All items",
            getValue: (i) => i.id,
            getLabel: (i) => i.name
        });

        form.addEventListener("submit", (e) => {
            e.preventDefault();
            errorEl.textContent = "";

            const itemId = itemSel.value;
            const qty    = parseInt($("#damagedQty").value, 10);
            const date   = dateInput.value;
            const note   = $("#damagedNote").value.trim();

            if (!itemId)                     return void (errorEl.textContent = "Please select an item.");
            if (!isFinite(qty) || qty <= 0)  return void (errorEl.textContent = "Quantity must be a positive number.");
            if (!date)                       return void (errorEl.textContent = "Please choose a date.");
            if (date > today())              return void (errorEl.textContent = "Date cannot be in the future.");
            if (qty > stock(itemId)) {
                return void (errorEl.textContent = `Only ${stock(itemId)} valid units of this item are in stock.`);
            }

            D.txs.push({
                id: uid(),
                date,
                itemId,
                type: "out",
                qty,
                note,
                user: me.name,
                reason: "damaged",
                price: findItem(itemId).price
            });
            save();
            renderTable();
            form.reset();
            dateInput.value = today();
        });

        function renderTable() {
            const from = fromEl.value;
            const to   = toEl.value;
            const filter = itemFilter.value;

            const list = D.txs.filter((t) =>
                isDmg(t) &&
                t.date >= from &&
                t.date <= to &&
                (!filter || t.itemId === filter)
            ).sort((a, b) => b.date.localeCompare(a.date));

            if (list.length === 0) {
                tbody.innerHTML = emptyRow(7, "No damaged stock recorded in this period.");
                return;
            }

            tbody.innerHTML = list.map((t) => {
                const it = findItem(t.itemId);
                return `
                    <tr>
                        <td>${esc(t.date)}</td>
                        <td>${esc(it?.name || "(deleted)")}</td>
                        <td class="num">${t.qty}</td>
                        <td class="num">${money(amountOf(t))}</td>
                        <td>${esc(t.note || "")}</td>
                        <td>${esc(t.user || "")}</td>
                        <td><button class="action-btn" data-tx="${t.id}">Edit</button></td>
                    </tr>`;
            }).join("");

            $$("[data-tx]", tbody).forEach((btn) => {
                btn.onclick = () => {
                    const tx = D.txs.find((t) => t.id === btn.dataset.tx);
                    if (!tx) return;
                    const newQty = prompt(`New quantity (current: ${tx.qty}):`, tx.qty);
                    if (newQty === null) return;
                    const qty = parseInt(newQty, 10);
                    if (!isFinite(qty) || qty <= 0) return alert("Enter a positive number.");
                    tx.qty = qty;
                    tx.edited = true;
                    save();
                    renderTable();
                };
            });
        }

        fromEl.addEventListener("change", renderTable);
        toEl.addEventListener("change", renderTable);
        itemFilter.addEventListener("change", renderTable);
        renderTable();
    }

    /* ============================================================
       16. PAGE: SUPPLIERS
       ============================================================ */
    function initSuppliersPage() {
        if (!requireAuth()) return;

        const form    = $("#supplierForm");
        const errorEl = $("#supplierFormError");
        const tbody   = $("#suppliersTableBody");

        form.addEventListener("submit", (e) => {
            e.preventDefault();
            errorEl.textContent = "";

            const name    = $("#supplierName").value.trim();
            const phone   = $("#supplierPhone").value.trim();
            const email   = $("#supplierEmail").value.trim();
            const address = $("#supplierAddress").value.trim();

            if (!name) return void (errorEl.textContent = "Name is required.");
            if (email && !/^[^@\s]+@[^@\s]+\.[A-Za-z]{2,}$/.test(email)) {
                return void (errorEl.textContent = "Please enter a valid email address.");
            }
            if (D.sups.some((s) => s.name.toLowerCase() === name.toLowerCase())) {
                return void (errorEl.textContent = "A supplier with this name already exists.");
            }

            D.sups.push({ id: uid(), name, phone, email, address });
            save();
            renderTable();
            form.reset();
        });

        function renderTable() {
            if (D.sups.length === 0) {
                tbody.innerHTML = emptyRow(6, "No suppliers yet. Add one above.");
                return;
            }

            tbody.innerHTML = D.sups.map((s) => {
                const count = D.items.filter((i) => i.supId === s.id).length;
                const isAdmin = me.role === "admin";
                return `
                    <tr>
                        <td>${esc(s.name)}</td>
                        <td>${esc(s.phone || "")}</td>
                        <td>${esc(s.email || "")}</td>
                        <td>${esc(s.address || "")}</td>
                        <td class="num">${count}</td>
                        <td>
                            <button class="action-btn" data-edit="${s.id}">Edit</button>
                            ${isAdmin ? `<button class="action-btn danger" data-delete="${s.id}">Delete</button>` : ""}
                        </td>
                    </tr>`;
            }).join("");

            $$("[data-edit]", tbody).forEach((btn) => {
                btn.onclick = () => {
                    const s = findSup(btn.dataset.edit);
                    const name = prompt("Supplier name:", s.name);
                    if (name === null) return;
                    const phone = prompt("Phone:", s.phone || "");
                    if (phone === null) return;
                    const email = prompt("Email:", s.email || "");
                    if (email === null) return;
                    const address = prompt("Address:", s.address || "");
                    if (address === null) return;
                    s.name    = name.trim() || s.name;
                    s.phone   = phone.trim();
                    s.email   = email.trim();
                    s.address = address.trim();
                    save();
                    renderTable();
                };
            });

            $$("[data-delete]", tbody).forEach((btn) => {
                btn.onclick = () => {
                    if (!confirm("Delete this supplier?")) return;
                    const id = btn.dataset.delete;
                    D.sups = D.sups.filter((s) => s.id !== id);
                    D.items.forEach((i) => { if (i.supId === id) i.supId = ""; });
                    save();
                    renderTable();
                };
            });
        }

        renderTable();
    }

    /* ============================================================
       17. PAGE: REPORTS
       ============================================================ */
    function initReportsPage() {
        if (!requireAuth()) return;

        const fromEl     = $("#reportFrom");
        const toEl       = $("#reportTo");
        const checklist  = $("#reportItemsChecklist");
        const tbody      = $("#reportTableBody");
        const selectAll  = $("#selectAllItemsBtn");
        const clearAll   = $("#clearAllItemsBtn");
        const downloadBtn = $("#downloadExcelBtn");

        fromEl.value = firstOfMonth();
        toEl.value   = today();

        let excluded = new Set();

        function renderChecklist() {
            if (D.items.length === 0) {
                checklist.innerHTML = `<p class="empty-row">No items yet.</p>`;
                return;
            }
            checklist.innerHTML = D.items.map((i) => {
                const checked = !excluded.has(i.id);
                return `
                    <label>
                        <input type="checkbox" data-item="${i.id}" ${checked ? "checked" : ""}>
                        ${esc(i.name)}
                    </label>`;
            }).join("");

            $$("[data-item]", checklist).forEach((cb) => {
                cb.onchange = () => {
                    if (cb.checked) excluded.delete(cb.dataset.item);
                    else excluded.add(cb.dataset.item);
                    renderTable();
                };
            });
        }

        function computeRows() {
            const from = fromEl.value;
            const to   = toEl.value;
            const inRange = D.txs.filter((t) => t.date >= from && t.date <= to);

            return D.items
                .filter((i) => !excluded.has(i.id))
                .map((i) => {
                    const mine = inRange.filter((t) => t.itemId === i.id);
                    const inQty  = mine.filter((t) => t.type === "in").reduce((s, t) => s + t.qty, 0);
                    const outQty = mine.filter((t) => t.type === "out" && t.reason !== "damaged").reduce((s, t) => s + t.qty, 0);
                    const dmgQty = mine.filter((t) => t.type === "out" && t.reason === "damaged").reduce((s, t) => s + t.qty, 0);

                    // Closing = current stock minus any movements after `to`
                    const after = D.txs
                        .filter((t) => t.itemId === i.id && t.date > to)
                        .reduce((s, t) => s + (t.type === "in" ? t.qty : -t.qty), 0);
                    const closing = stock(i.id) - after;
                    const opening = closing - inQty + outQty + dmgQty;

                    return { item: i, opening, inQty, outQty, dmgQty, closing };
                });
        }

        function renderTable() {
            const rows = computeRows();
            if (rows.length === 0) {
                tbody.innerHTML = emptyRow(7, "Select at least one item above to see its report.");
                return;
            }

            let totalValue = 0;
            tbody.innerHTML = rows.map((r) => {
                const value = r.closing * r.item.price;
                totalValue += value;
                return `
                    <tr>
                        <td>${esc(r.item.name)}</td>
                        <td class="num">${r.opening}</td>
                        <td class="num">${r.inQty}</td>
                        <td class="num">${r.outQty}</td>
                        <td class="num">${r.dmgQty}</td>
                        <td class="num">${r.closing}</td>
                        <td class="num">${money(value)}</td>
                    </tr>`;
            }).join("") + `
                <tr>
                    <th>Total value</th>
                    <th></th><th></th><th></th><th></th><th></th>
                    <th class="num">${money(totalValue)}</th>
                </tr>`;
        }

        selectAll.onclick = () => { excluded.clear(); renderChecklist(); renderTable(); };
        clearAll.onclick  = () => { excluded = new Set(D.items.map((i) => i.id)); renderChecklist(); renderTable(); };

        fromEl.addEventListener("change", renderTable);
        toEl.addEventListener("change", renderTable);

        downloadBtn.addEventListener("click", () => {
            if (typeof XLSX === "undefined") {
                alert("Excel library not loaded. Check your internet connection.");
                return;
            }
            const rows = computeRows();
            const data = [
                ["Stock Report", D.company.name || "Inventory System"],
                ["Period", fromEl.value, "to", toEl.value],
                ["Prepared", new Date().toISOString().slice(0, 10)],
                [],
                ["Item", "Opening", "In", "Sold / Issued", "Damaged", "Closing", "Value"],
                ...rows.map((r) => [
                    r.item.name, r.opening, r.inQty, r.outQty, r.dmgQty, r.closing,
                    +(r.closing * r.item.price).toFixed(2)
                ])
            ];
            const ws = XLSX.utils.aoa_to_sheet(data);
            const wb = XLSX.utils.book_new();
            XLSX.utils.book_append_sheet(wb, ws, "Stock Report");
            XLSX.writeFile(wb, `stock-report-${fromEl.value}-to-${toEl.value}.xlsx`);
        });

        renderChecklist();
        renderTable();
    }

    /* ============================================================
       18. PAGE: USERS
       ============================================================ */
    function initUsersPage() {
        if (!requireAdmin()) return;

        const tbody = $("#usersTableBody");

        function render() {
            if (D.users.length === 0) {
                tbody.innerHTML = emptyRow(5, "No users yet.");
                return;
            }

            tbody.innerHTML = D.users.map((u) => {
                const isSelf = u.id === me.id;
                const role = u.role === "admin" ? "Administrator" : "Staff";
                const status = u.active === false
                    ? `<span class="status-badge status-zero">Deactivated</span>`
                    : `<span class="status-badge status-ok">Active</span>`;
                return `
                    <tr>
                        <td>${esc(u.name)}${isSelf ? " (you)" : ""}</td>
                        <td>${esc(u.email)}</td>
                        <td>${role}</td>
                        <td>${status}</td>
                        <td>
                            ${isSelf ? "" : `
                                <button class="action-btn" data-toggle="${u.id}">
                                    ${u.active === false ? "Reactivate" : "Deactivate"}
                                </button>
                            `}
                        </td>
                    </tr>`;
            }).join("");

            $$("[data-toggle]", tbody).forEach((btn) => {
                btn.onclick = () => {
                    const u = D.users.find((x) => x.id === btn.dataset.toggle);
                    if (!u) return;
                    u.active = u.active === false ? true : false;
                    save();
                    render();
                };
            });
        }

        render();
    }

    /* ============================================================
       19. PAGE: ACCOUNT
       ============================================================ */
    function initAccountPage() {
        if (!requireAuth()) return;

        const form       = $("#accountForm");
        const errorEl    = $("#accountFormError");
        const nameInput  = $("#accountName");
        const emailInput = $("#accountEmail");
        const roleInput  = $("#accountRole");

        const pwForm     = $("#passwordForm");
        const pwError    = $("#passwordFormError");

        const currentUser = D.users.find((u) => u.id === me.id);

        nameInput.value  = currentUser.name;
        emailInput.value = currentUser.email;
        roleInput.value  = currentUser.role === "admin" ? "Administrator" : "Staff";

        form.addEventListener("submit", (e) => {
            e.preventDefault();
            errorEl.textContent = "";

            const name  = nameInput.value.trim();
            const email = emailInput.value.trim().toLowerCase();

            if (name.length < 2) return void (errorEl.textContent = "Please enter your full name.");
            if (!/^[^@\s]+@[^@\s]+\.[A-Za-z]{2,}$/.test(email)) {
                return void (errorEl.textContent = "Please enter a valid email address.");
            }
            if (D.users.some((u) => u.email === email && u.id !== me.id)) {
                return void (errorEl.textContent = "Another account already uses this email.");
            }

            currentUser.name  = name;
            currentUser.email = email;
            me = { ...me, name };
            store.set(KEYS.session, me);
            save();
            errorEl.style.color = "var(--ok)";
            errorEl.textContent = "Your details were updated.";
            setTimeout(() => { errorEl.style.color = ""; errorEl.textContent = ""; }, 2500);
        });

        pwForm.addEventListener("submit", async (e) => {
            e.preventDefault();
            pwError.textContent = "";

            const cur = $("#currentPassword").value;
            const nw  = $("#newPassword").value;
            const cf  = $("#confirmNewPassword").value;

            const hashedCurrent = await hashPassword(cur);
            if (currentUser.pass !== hashedCurrent) {
                return void (pwError.textContent = "Current password is incorrect.");
            }
            if (!/^(?=.*[A-Za-z])(?=.*\d).{8,}$/.test(nw)) {
                return void (pwError.textContent = "New password must be at least 8 characters and contain letters and numbers.");
            }
            if (nw !== cf) {
                return void (pwError.textContent = "The new passwords do not match.");
            }

            currentUser.pass = await hashPassword(nw);
            save();
            pwForm.reset();
            pwError.style.color = "var(--ok)";
            pwError.textContent = "Password changed.";
            setTimeout(() => { pwError.style.color = ""; pwError.textContent = ""; }, 2500);
        });
    }

    /* ============================================================
       20. PAGE: COMPANY
       ============================================================ */
    function initCompanyPage() {
        if (!requireAdmin()) return;

        const form    = $("#companyForm");
        const errorEl = $("#companyFormError");
        const logoIn  = $("#companyLogo");

        // Prefill
        $("#companyName").value        = D.company.name || "";
        $("#companyPhone").value       = D.company.phone || "";
        $("#companyEmail").value       = D.company.email || "";
        $("#companyHours").value       = D.company.hours || "";
        $("#companyAddress").value     = D.company.address || "";
        $("#companyDescription").value = D.company.description || "";
        $("#companyMission").value     = D.company.mission || "";
        $("#companyServices").value    = D.company.services || "";

        let pendingLogo = null;

        logoIn.addEventListener("change", (e) => {
            const file = e.target.files[0];
            if (!file) return;
            if (file.size > 300 * 1024) {
                errorEl.textContent = "Logo must be under 300 KB.";
                logoIn.value = "";
                return;
            }
            const reader = new FileReader();
            reader.onload = () => {
                pendingLogo = reader.result;
                errorEl.style.color = "var(--ok)";
                errorEl.textContent = "Logo ready. Click Save Profile to keep it.";
                setTimeout(() => { errorEl.style.color = ""; errorEl.textContent = ""; }, 2500);
            };
            reader.readAsDataURL(file);
        });

        form.addEventListener("submit", (e) => {
            e.preventDefault();
            errorEl.textContent = "";

            const name = $("#companyName").value.trim();
            if (!name) return void (errorEl.textContent = "Company name is required.");

            const email = $("#companyEmail").value.trim();
            if (email && !/^[^@\s]+@[^@\s]+\.[A-Za-z]{2,}$/.test(email)) {
                return void (errorEl.textContent = "Please enter a valid email address.");
            }

            D.company = {
                name,
                phone:       $("#companyPhone").value.trim(),
                email,
                hours:       $("#companyHours").value.trim(),
                address:     $("#companyAddress").value.trim(),
                description: $("#companyDescription").value.trim(),
                mission:     $("#companyMission").value.trim(),
                services:    $("#companyServices").value.trim(),
                logo:        pendingLogo || D.company.logo || ""
            };
            save();
            pendingLogo = null;
            errorEl.style.color = "var(--ok)";
            errorEl.textContent = "Company profile saved.";
            setTimeout(() => { errorEl.style.color = ""; errorEl.textContent = ""; }, 2500);
        });
    }

    /* ============================================================
       21. BOOT — detect page and run the right initializer
       ============================================================ */
    const PAGE_INIT = {
        "login.html":     initLoginPage,
        "signup.html":    initSignupPage,
        "dashboard.html": initDashboardPage,
        "items.html":     initItemsPage,
        "item-add.html":  initItemFormPage,
        "stock.html":     initStockPage,
        "sales.html":     initSalesPage,
        "damaged.html":   initDamagedPage,
        "suppliers.html": initSuppliersPage,
        "reports.html":   initReportsPage,
        "users.html":     initUsersPage,
        "account.html":   initAccountPage,
        "company.html":   initCompanyPage
    };

    document.addEventListener("DOMContentLoaded", () => {
        markActiveNav();
        initTopButton();
        initSignOutLink();

        const page = location.pathname.split("/").pop() || "dashboard.html";
        const init = PAGE_INIT[page];
        if (init) init();
    });
})();