#!/bin/bash
# ============================================================
# INVENTORY MANAGEMENT SYSTEM — Daily backup script
# Implements FR-058 and NFR-009 (30-day retention, <2h restore)
#
# Usage:
#   chmod +x backup.sh
#   ./backup.sh
#
# Schedule with cron (runs every day at 2:00 AM):
#   crontab -e
#   0 2 * * * /full/path/to/backup.sh >> /var/log/ims_backup.log 2>&1
# ============================================================

# ---- Configuration ----
DB_HOST="localhost"
DB_USER="root"
DB_PASS=""                      # Empty for XAMPP default — change on production
DB_NAME="inventory_db"
BACKUP_DIR="/var/backups/inventory"
RETENTION_DAYS=30
TIMESTAMP=$(date +"%Y%m%d_%H%M%S")
BACKUP_FILE="${BACKUP_DIR}/${DB_NAME}_${TIMESTAMP}.sql.gz"

# ---- Ensure backup directory exists ----
mkdir -p "$BACKUP_DIR"

# ---- Run the dump ----
if [ -n "$DB_PASS" ]; then
    MYSQL_PWD="$DB_PASS" mysqldump --host="$DB_HOST" --user="$DB_USER" --single-transaction "$DB_NAME" | gzip > "$BACKUP_FILE"
else
    mysqldump --host="$DB_HOST" --user="$DB_USER" --single-transaction "$DB_NAME" | gzip > "$BACKUP_FILE"
fi

if [ $? -eq 0 ]; then
    SIZE=$(du -h "$BACKUP_FILE" | cut -f1)
    echo "[$(date)] Backup succeeded: $BACKUP_FILE ($SIZE)"
else
    echo "[$(date)] BACKUP FAILED" >&2
    exit 1
fi

# ---- Delete backups older than 30 days ----
find "$BACKUP_DIR" -name "${DB_NAME}_*.sql.gz" -mtime +$RETENTION_DAYS -delete
echo "[$(date)] Removed backups older than $RETENTION_DAYS days"

# ---- Verify the most recent backup is valid ----
LATEST=$(ls -t "$BACKUP_DIR"/*.sql.gz 2>/dev/null | head -1)
if [ -n "$LATEST" ] && gzip -t "$LATEST"; then
    echo "[$(date)] Latest backup is valid: $LATEST"
else
    echo "[$(date)] WARNING: Latest backup failed the integrity check" >&2
fi