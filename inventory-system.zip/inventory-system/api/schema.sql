-- ============================================================
-- INVENTORY MANAGEMENT SYSTEM — Database Schema
-- Matches SRS Tables 25–31
-- ============================================================

CREATE DATABASE IF NOT EXISTS inventory_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE inventory_db;

-- 1. Users (Table 25)
CREATE TABLE IF NOT EXISTS users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(150) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    role ENUM('admin', 'staff') DEFAULT 'staff',
    mfa_enabled BOOLEAN DEFAULT TRUE,
    is_active BOOLEAN DEFAULT TRUE,
    failed_attempts INT DEFAULT 0,
    locked_until DATETIME NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- 2. OTP Codes (Table 26)
CREATE TABLE IF NOT EXISTS otp_codes (
    otp_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    code_hash VARCHAR(255) NOT NULL,
    expires_at DATETIME NOT NULL,
    attempts INT DEFAULT 0,
    is_used BOOLEAN DEFAULT FALSE,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
);

-- 3. Company Profile (Table 27)
CREATE TABLE IF NOT EXISTS company_profile (
    profile_id INT PRIMARY KEY DEFAULT 1,
    company_name VARCHAR(150) NOT NULL,
    logo_path VARCHAR(255),
    description TEXT,
    mission TEXT,
    services TEXT,
    address VARCHAR(255),
    phone VARCHAR(20),
    email VARCHAR(150),
    opening_hours VARCHAR(100),
    updated_by INT,
    updated_at DATETIME,
    FOREIGN KEY (updated_by) REFERENCES users(user_id) ON DELETE SET NULL
);

-- 4. Suppliers (Table 28) — includes address
CREATE TABLE IF NOT EXISTS suppliers (
    supplier_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(150) NOT NULL,
    phone VARCHAR(20),
    email VARCHAR(150),
    address VARCHAR(255),
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- 5. Items (Table 29)
CREATE TABLE IF NOT EXISTS items (
    item_id INT AUTO_INCREMENT PRIMARY KEY,
    sku VARCHAR(50) UNIQUE NOT NULL,
    name VARCHAR(150) NOT NULL,
    category VARCHAR(80),
    supplier_id INT NULL,
    unit_price DECIMAL(10,2) NOT NULL,
    min_stock INT DEFAULT 5,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (supplier_id) REFERENCES suppliers(supplier_id) ON DELETE SET NULL
);

-- 6. Stock Movements (Table 30)
CREATE TABLE IF NOT EXISTS stock_movements (
    movement_id INT AUTO_INCREMENT PRIMARY KEY,
    item_id INT NOT NULL,
    movement_date DATE NOT NULL,
    type ENUM('in', 'out') NOT NULL,
    reason ENUM('sold', 'damaged', 'internal') NULL,
    quantity INT NOT NULL CHECK (quantity > 0),
    unit_price DECIMAL(10,2) NOT NULL,
    note VARCHAR(255),
    recorded_by INT NOT NULL,
    is_edited BOOLEAN DEFAULT FALSE,
    edited_by INT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (item_id) REFERENCES items(item_id) ON DELETE CASCADE,
    FOREIGN KEY (recorded_by) REFERENCES users(user_id),
    FOREIGN KEY (edited_by) REFERENCES users(user_id) ON DELETE SET NULL
);

-- 7. Audit Log (Table 31)
CREATE TABLE IF NOT EXISTS audit_log (
    log_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    action ENUM('create', 'update', 'delete', 'login') NOT NULL,
    table_name VARCHAR(50),
    record_id INT,
    details TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE SET NULL
);

-- ============================================================
-- OPTIONAL: Seed data for testing
-- ============================================================

-- Default company profile row (FR-001 needs something to show)
INSERT INTO company_profile (profile_id, company_name, description, mission, address, phone, email, opening_hours)
VALUES (1, 'My Inventory System', 'A simple, reliable stock manager.', 'Keep your inventory accurate and up to date.', 'Nairobi, Kenya', '+254 700 000 000', 'info@example.com', 'Mon-Sat, 8:00-18:00')
ON DUPLICATE KEY UPDATE company_name = VALUES(company_name);