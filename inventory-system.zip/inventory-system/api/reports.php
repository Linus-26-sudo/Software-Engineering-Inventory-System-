<?php
session_start();
header('Content-Type: application/json');
require_once 'db.php';

if (!isset($_SESSION['user'])) {
    http_response_code(401);
    die(json_encode(["error" => "Unauthorized"]));
}

// GET /api/reports.php?from=YYYY-MM-DD&to=YYYY-MM-DD&items=1,2,3
$from = $_GET['from'] ?? date('Y-m-01');
$to   = $_GET['to']   ?? date('Y-m-d');
$itemIds = array_filter(array_map('intval', explode(',', $_GET['items'] ?? '')));

if (!$itemIds) {
    die(json_encode(["error" => "Select at least one item."]));
}

$placeholders = implode(',', array_fill(0, count($itemIds), '?'));
$types = str_repeat('i', count($itemIds));

$sql = "
    SELECT
        i.item_id, i.name, i.unit_price,
        COALESCE(SUM(CASE WHEN m.type='in' AND m.movement_date BETWEEN ? AND ? THEN m.quantity ELSE 0 END), 0) AS in_qty,
        COALESCE(SUM(CASE WHEN m.type='out' AND m.reason='sold' AND m.movement_date BETWEEN ? AND ? THEN m.quantity ELSE 0 END), 0) AS sold_qty,
        COALESCE(SUM(CASE WHEN m.type='out' AND m.reason='damaged' AND m.movement_date BETWEEN ? AND ? THEN m.quantity ELSE 0 END), 0) AS dmg_qty,
        COALESCE(SUM(CASE WHEN m.type='out' AND m.reason='internal' AND m.movement_date BETWEEN ? AND ? THEN m.quantity ELSE 0 END), 0) AS internal_qty,
        COALESCE(SUM(CASE WHEN m.type='in' THEN m.quantity ELSE -m.quantity END), 0) AS current_stock,
        COALESCE(SUM(CASE WHEN m.movement_date > ? THEN (CASE WHEN m.type='in' THEN m.quantity ELSE -m.quantity END) ELSE 0 END), 0) AS after_period
    FROM items i
    LEFT JOIN stock_movements m ON i.item_id = m.item_id
    WHERE i.item_id IN ($placeholders)
    GROUP BY i.item_id
    ORDER BY i.name
";

$stmt = $conn->prepare($sql);
// Params: from, to, from, to, from, to, from, to, to, then item IDs
$stmt->bind_param("sssssssss" . $types,
    $from, $to, $from, $to, $from, $to, $from, $to, $to,
    ...$itemIds
);
$stmt->execute();
$rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

foreach ($rows as &$r) {
    // Appendix G formulas
    $r['closing'] = (int)$r['current_stock'] - (int)$r['after_period'];
    $r['opening'] = $r['closing'] - (int)$r['in_qty'] + (int)$r['sold_qty'] + (int)$r['internal_qty'] + (int)$r['dmg_qty'];
    $r['value']   = $r['closing'] * (float)$r['unit_price'];
}

echo json_encode([
    "from" => $from,
    "to" => $to,
    "rows" => $rows,
    "total_value" => array_sum(array_column($rows, 'value'))
]);