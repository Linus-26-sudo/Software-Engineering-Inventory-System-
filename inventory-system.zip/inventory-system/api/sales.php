<?php
session_start();
header('Content-Type: application/json');
require_once 'db.php';

if (!isset($_SESSION['user'])) {
    http_response_code(401);
    die(json_encode(["error" => "Unauthorized"]));
}

$from   = $_GET['from'] ?? date('Y-m-01');
$to     = $_GET['to']   ?? date('Y-m-d');
$itemId = isset($_GET['item_id']) && $_GET['item_id'] !== '' ? (int)$_GET['item_id'] : null;

$sql = "
    SELECT
        m.movement_id, m.movement_date, m.quantity, m.unit_price, m.note,
        i.item_id, i.name AS item_name, i.sku,
        u.full_name AS user_name
    FROM stock_movements m
    JOIN items i ON m.item_id = i.item_id
    JOIN users u ON m.recorded_by = u.user_id
    WHERE m.type = 'out'
      AND m.reason = 'sold'
      AND m.movement_date BETWEEN ? AND ?
";

if ($itemId) {
    $sql .= " AND m.item_id = ? ";
    $sql .= " ORDER BY m.movement_date DESC, m.movement_id DESC";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssi", $from, $to, $itemId);
} else {
    $sql .= " ORDER BY m.movement_date DESC, m.movement_id DESC";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $from, $to);
}

$stmt->execute();
$rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// Compute totals
$units  = 0;
$amount = 0;
$itemSet = [];
foreach ($rows as $r) {
    $units  += (int)$r['quantity'];
    $amount += (int)$r['quantity'] * (float)$r['unit_price'];
    $itemSet[$r['item_id']] = true;
}

echo json_encode([
    "from"         => $from,
    "to"           => $to,
    "rows"         => $rows,
    "totals"       => [
        "units"       => $units,
        "amount"      => round($amount, 2),
        "sales_count" => count($rows),
        "items_sold"  => count($itemSet)
    ]
]);