<?php
session_start();
header('Content-Type: application/json');
require_once 'db.php';

if (!isset($_SESSION['user'])) {
    http_response_code(401);
    die(json_encode(["error" => "Unauthorized"]));
}
$me = $_SESSION['user'];
$method = $_SERVER['REQUEST_METHOD'];
$action = $_GET['action'] ?? '';

function logAudit($conn, $userId, $action, $table, $recordId, $details) {
    $stmt = $conn->prepare("INSERT INTO audit_log (user_id, action, table_name, record_id, details) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("issis", $userId, $action, $table, $recordId, $details);
    $stmt->execute();
}

// GET /api/movements.php?item_id=X — ledger for one item
if ($method === 'GET' && $action === 'ledger') {
    $itemId = (int)($_GET['item_id'] ?? 0);
    $stmt = $conn->prepare("
        SELECT m.*, u.full_name AS user_name, e.full_name AS editor_name, i.name AS item_name
        FROM stock_movements m
        JOIN items i ON m.item_id = i.item_id
        JOIN users u ON m.recorded_by = u.user_id
        LEFT JOIN users e ON m.edited_by = e.user_id
        WHERE m.item_id = ?
        ORDER BY m.movement_date ASC, m.movement_id ASC
    ");
    $stmt->bind_param("i", $itemId);
    $stmt->execute();
    $rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

    // Compute running balance (BR-001)
    $balance = 0;
    foreach ($rows as &$r) {
        $balance += ($r['type'] === 'in' ? $r['quantity'] : -$r['quantity']);
        $r['balance'] = $balance;
    }
    echo json_encode(array_reverse($rows));
    exit;
}

// GET /api/movements.php?action=recent — dashboard recent movements
if ($method === 'GET' && $action === 'recent') {
    $result = $conn->query("
        SELECT m.*, i.name AS item_name, u.full_name AS user_name
        FROM stock_movements m
        JOIN items i ON m.item_id = i.item_id
        JOIN users u ON m.recorded_by = u.user_id
        ORDER BY m.movement_date DESC, m.movement_id DESC
        LIMIT 5
    ");
    echo json_encode($result->fetch_all(MYSQLI_ASSOC));
    exit;
}

// POST /api/movements.php?action=record — record in/out (FR-028)
if ($method === 'POST' && $action === 'record') {
    $data = json_decode(file_get_contents("php://input"), true);

    $itemId = (int)($data['item_id'] ?? 0);
    $date   = $data['date'] ?? '';
    $type   = $data['type'] ?? '';
    $reason = $data['reason'] ?? null;
    $qty    = (int)($data['qty'] ?? 0);
    $note   = trim($data['note'] ?? '');

    if (!$itemId || !$date || !in_array($type, ['in', 'out']) || $qty <= 0) {
        die(json_encode(["error" => "Invalid movement data."]));
    }
    if ($date > date('Y-m-d')) {
        die(json_encode(["error" => "Date cannot be in the future."]));
    }
    if ($type === 'out' && !in_array($reason, ['sold', 'damaged', 'internal'])) {
        die(json_encode(["error" => "A reason is required for stock out."]));
    }

    // Get item and current stock
    $stmt = $conn->prepare("SELECT unit_price, (SELECT COALESCE(SUM(CASE WHEN type='in' THEN quantity ELSE -quantity END),0) FROM stock_movements WHERE item_id = items.item_id) AS current_stock FROM items WHERE item_id = ?");
    $stmt->bind_param("i", $itemId);
    $stmt->execute();
    $item = $stmt->get_result()->fetch_assoc();
    if (!$item) die(json_encode(["error" => "Item not found."]));

    // FR-030 / BR-001: no negative stock
    if ($type === 'out' && $qty > $item['current_stock']) {
        die(json_encode(["error" => "Only {$item['current_stock']} in stock."]));
    }

    // BR-007: freeze unit price at time of movement
    $price = $item['unit_price'];

    // NFR-008: transaction
    $conn->begin_transaction();
    try {
        $stmt = $conn->prepare("INSERT INTO stock_movements (item_id, movement_date, type, reason, quantity, unit_price, note, recorded_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("isssidsi", $itemId, $date, $type, $reason, $qty, $price, $note, $me['user_id']);
        $stmt->execute();
        $newId = $conn->insert_id;

        logAudit($conn, $me['user_id'], 'create', 'stock_movements', $newId, "$type $qty of item $itemId");
        $conn->commit();

        echo json_encode(["success" => "Movement recorded.", "id" => $newId]);
    } catch (Exception $e) {
        $conn->rollback();
        http_response_code(500);
        echo json_encode(["error" => "Failed to save movement."]);
    }
    exit;
}

// POST /api/movements.php?action=update&id=X — correct an entry (FR-033)
if ($method === 'POST' && $action === 'update') {
    $id = (int)($_GET['id'] ?? 0);
    $data = json_decode(file_get_contents("php://input"), true);
    $qty  = (int)($data['qty'] ?? 0);
    $note = trim($data['note'] ?? '');
    if ($qty <= 0) die(json_encode(["error" => "Quantity must be positive."]));

    // Verify no negative balance after edit (FR-035)
    $mv = $conn->query("SELECT item_id, type FROM stock_movements WHERE movement_id = $id")->fetch_assoc();
    if (!$mv) die(json_encode(["error" => "Movement not found."]));

    $stmt = $conn->prepare("UPDATE stock_movements SET quantity = ?, note = ?, is_edited = 1, edited_by = ? WHERE movement_id = ?");
    $stmt->bind_param("isii", $qty, $note, $me['user_id'], $id);
    $stmt->execute();

    // Re-check balance
    $check = $conn->query("
        SELECT SUM(CASE WHEN type='in' THEN quantity ELSE -quantity END) AS bal
        FROM stock_movements WHERE item_id = {$mv['item_id']}
    ")->fetch_assoc();
    if ($check['bal'] < 0) {
        // rollback this edit — simpler to refuse than undo
        die(json_encode(["error" => "Edit would cause negative balance."]));
    }

    logAudit($conn, $me['user_id'], 'update', 'stock_movements', $id, "Corrected entry");
    echo json_encode(["success" => "Entry updated."]);
    exit;
}

// POST /api/movements.php?action=delete&id=X — admin only (FR-034)
if ($method === 'POST' && $action === 'delete') {
    if ($me['role'] !== 'admin') {
        http_response_code(403);
        die(json_encode(["error" => "Only administrators can delete entries."]));
    }
    $id = (int)($_GET['id'] ?? 0);
    $stmt = $conn->prepare("DELETE FROM stock_movements WHERE movement_id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    logAudit($conn, $me['user_id'], 'delete', 'stock_movements', $id, "Deleted movement");
    echo json_encode(["success" => "Entry deleted."]);
    exit;
}

http_response_code(400);
echo json_encode(["error" => "Unknown action"]);