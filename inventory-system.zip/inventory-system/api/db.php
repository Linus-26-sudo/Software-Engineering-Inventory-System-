<?php
// api/db.php
$host = "localhost";
$user = "root"; // Update for your server
$pass = "";     // Update for your server
$db   = "inventory_db";

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    http_response_code(500);
    die(json_encode(["error" => "Database connection failed: " . $conn->connect_error]));
}

// Ensure correct encoding
$conn->set_charset("utf8mb4");
?>