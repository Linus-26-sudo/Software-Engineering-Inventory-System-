<?php
session_start();
header('Content-Type: application/json');
require_once 'db.php';

// NFR-006: Server-side role check
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    http_response_code(403);
    die(json_encode(["error" => "Admin access required."]));
}

$me = $_SESSION['user'];
$method = $_SERVER['REQUEST_METHOD'];
$action = $_GET['action'] ?? '';

// GET: List all users
if ($method === 'GET') {
    $result = $conn->query("SELECT user_id, full_name, email, role, is_active, created_at FROM users ORDER BY full_name");
    echo json_encode($result->fetch_all(MYSQLI_ASSOC));
    exit;
}

// POST: Toggle active status
if ($method === 'POST' && $action === 'toggle') {
    $id = (int)($_GET['id'] ?? 0);
    
    if ($id === $me['user_id']) {
        http_response_code(400);
        die(json_encode(["error" => "You cannot deactivate your own account."]));
    }
    
    $conn->query("UPDATE users SET is_active = NOT is_active WHERE user_id = $id");
    echo json_encode(["success" => "User status toggled."]);
    exit;
}

// POST: Change Role
if ($method === 'POST' && $action === 'role') {
    $id = (int)($_GET['id'] ?? 0);
    $d = json_decode(file_get_contents("php://input"), true);
    $role = $d['role'] === 'admin' ? 'admin' : 'staff';
    
    if ($id === $me['user_id']) {
        http_response_code(400);
        die(json_encode(["error" => "You cannot change your own role."]));
    }
    
    $stmt = $conn->prepare("UPDATE users SET role = ? WHERE user_id = ?");
    $stmt->bind_param("si", $role, $id);
    $stmt->execute();
    
    echo json_encode(["success" => "Role updated."]);
    exit;
}

http_response_code(400);
echo json_encode(["error" => "Unknown action"]);