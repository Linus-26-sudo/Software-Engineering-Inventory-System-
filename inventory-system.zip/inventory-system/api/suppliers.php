<?php
session_start();
header('Content-Type: application/json');
require_once 'db.php';

if (!isset($_SESSION['user'])) {
    http_response_code(401);
    die(json_encode(["error" => "Unauthorized"]));
}
$me = $_SESSION['user'];
$method = $_SERVER['REQUEST_METHOD'];
$action = $_GET['action'] ?? '';

if ($method === 'GET') {
    $result = $conn->query("
        SELECT s.*, COUNT(i.item_id) AS item_count
        FROM suppliers s
        LEFT JOIN items i ON i.supplier_id = s.supplier_id
        GROUP BY s.supplier_id
        ORDER BY s.name
    ");
    echo json_encode($result->fetch_all(MYSQLI_ASSOC));
    exit;
}

if ($method === 'POST' && $action === 'create') {
    $d = json_decode(file_get_contents("php://input"), true);
    $name = trim($d['name'] ?? '');
    if (!$name) die(json_encode(["error" => "Name required."]));

    $stmt = $conn->prepare("INSERT INTO suppliers (name, phone, email, address) VALUES (?, ?, ?, ?)");
    // If your schema doesn't have address, adjust — this matches the SRS Table 28
    $phone = trim($d['phone'] ?? '');
    $email = trim($d['email'] ?? '');
    $address = trim($d['address'] ?? '');
    $stmt->bind_param("ssss", $name, $phone, $email, $address);
    $stmt->execute();
    echo json_encode(["success" => "Supplier added.", "id" => $conn->insert_id]);
    exit;
}

if ($method === 'POST' && $action === 'update') {
    $id = (int)($_GET['id'] ?? 0);
    $d = json_decode(file_get_contents("php://input"), true);
    $stmt = $conn->prepare("UPDATE suppliers SET name = ?, phone = ?, email = ?, address = ? WHERE supplier_id = ?");
    $stmt->bind_param("ssssi", $d['name'], $d['phone'], $d['email'], $d['address'], $id);
    $stmt->execute();
    echo json_encode(["success" => "Supplier updated."]);
    exit;
}

if ($method === 'POST' && $action === 'delete') {
    if ($me['role'] !== 'admin') {
        http_response_code(403);
        die(json_encode(["error" => "Only administrators can delete suppliers."]));
    }
    $id = (int)($_GET['id'] ?? 0);
    // BR-014: items keep existing but lose the link (FK ON DELETE SET NULL)
    $stmt = $conn->prepare("DELETE FROM suppliers WHERE supplier_id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    echo json_encode(["success" => "Supplier deleted."]);
    exit;
}

http_response_code(400);
echo json_encode(["error" => "Unknown action"]);