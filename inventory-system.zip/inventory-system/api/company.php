<?php
session_start();
header('Content-Type: application/json');
require_once 'db.php';

$method = $_SERVER['REQUEST_METHOD'];
$action = $_GET['action'] ?? '';

// GET /api/company.php — public read (no auth required, FR-001)
if ($method === 'GET') {
    $res = $conn->query("SELECT * FROM company_profile WHERE profile_id = 1");
    $row = $res->fetch_assoc();
    if (!$row) {
        echo json_encode([
            "company_name" => "Inventory Management System",
            "description" => "Your inventory, under control.",
            "mission" => "", "services" => "",
            "address" => "", "phone" => "", "email" => "",
            "opening_hours" => "", "logo_path" => ""
        ]);
    } else {
        echo json_encode($row);
    }
    exit;
}

// POST /api/company.php?action=update — admin only (FR-003, BR-008)
if ($method === 'POST' && $action === 'update') {
    if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
        http_response_code(403);
        die(json_encode(["error" => "Only administrators can edit the profile."]));
    }
    $me = $_SESSION['user'];
    $d = json_decode(file_get_contents("php://input"), true);

    $stmt = $conn->prepare("
        INSERT INTO company_profile (profile_id, company_name, logo_path, description, mission, services, address, phone, email, opening_hours, updated_by, updated_at)
        VALUES (1, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())
        ON DUPLICATE KEY UPDATE
            company_name = VALUES(company_name),
            logo_path = VALUES(logo_path),
            description = VALUES(description),
            mission = VALUES(mission),
            services = VALUES(services),
            address = VALUES(address),
            phone = VALUES(phone),
            email = VALUES(email),
            opening_hours = VALUES(opening_hours),
            updated_by = VALUES(updated_by),
            updated_at = NOW()
    ");
    $stmt->bind_param("sssssssssi",
        $d['company_name'], $d['logo_path'], $d['description'], $d['mission'],
        $d['services'], $d['address'], $d['phone'], $d['email'],
        $d['opening_hours'], $me['user_id']
    );
    $stmt->execute();

    // Audit
    $conn->query("INSERT INTO audit_log (user_id, action, table_name, details) VALUES ({$me['user_id']}, 'update', 'company_profile', 'Updated company profile')");

    echo json_encode(["success" => "Profile saved."]);
    exit;
}

http_response_code(400);
echo json_encode(["error" => "Unknown action"]);