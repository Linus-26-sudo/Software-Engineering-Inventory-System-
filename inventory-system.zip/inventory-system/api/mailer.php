<?php
// api/mailer.php
function sendMfaCode($email, $code) {
    // NFR-009 / FR-009: In a real setup, you'd use PHPMailer or SMTP.
    // For the local prototype, we return the code in the JSON response 
    // so the UI can display it (simulating an email inbox).
    
    // Example SMTP implementation (uncomment to use):
    //mail($email, "Your Sign-in Code", "Your code is: $code", "From: no-reply@inventory.com");
    
    return true;
}
?>