<?php
session_start();
header('Content-Type: application/json');
require_once 'db.php';

// NFR-006: Server-side role check
if (!isset($_SESSION['user'])) {
    http_response_code(401);
    die(json_encode(["error" => "Unauthorized"]));
}
$me = $_SESSION['user'];

$method = $_SERVER['REQUEST_METHOD'];
$action = $_GET['action'] ?? '';

// Helper: log to audit (FR-057)
function logAudit($conn, $userId, $action, $table, $recordId, $details) {
    $stmt = $conn->prepare("INSERT INTO audit_log (user_id, action, table_name, record_id, details) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("issis", $userId, $action, $table, $recordId, $details);
    $stmt->execute();
}

// GET /api/items.php — list items with computed stock and status
if ($method === 'GET' && $action === '') {
    $sql = "
        SELECT i.item_id, i.sku, i.name, i.category, i.unit_price, i.min_stock,
               s.name AS supplier_name,
               COALESCE(SUM(CASE WHEN m.type = 'in' THEN m.quantity ELSE -m.quantity END), 0) AS current_stock
        FROM items i
        LEFT JOIN suppliers s ON i.supplier_id = s.supplier_id
        LEFT JOIN stock_movements m ON i.item_id = m.item_id
        GROUP BY i.item_id
        ORDER BY i.name
    ";
    $result = $conn->query($sql);
    $items = [];
    while ($row = $result->fetch_assoc()) {
        // BR-005: automatic status
        $q = (int)$row['current_stock'];
        $min = (int)$row['min_stock'];
        if ($q <= 0)       $row['status'] = ['key' => 'zero', 'label' => 'Out of stock'];
        elseif ($q <= $min) $row['status'] = ['key' => 'low', 'label' => 'Low stock'];
        else               $row['status'] = ['key' => 'ok', 'label' => 'In stock'];
        $items[] = $row;
    }
    echo json_encode($items);
    exit;
}

// GET /api/items.php?action=one&id=X
if ($method === 'GET' && $action === 'one') {
    $id = (int)($_GET['id'] ?? 0);
    $stmt = $conn->prepare("SELECT * FROM items WHERE item_id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    echo json_encode($stmt->get_result()->fetch_assoc() ?: null);
    exit;
}

// POST /api/items.php?action=create — add item (FR-022)
if ($method === 'POST' && $action === 'create') {
    $data = json_decode(file_get_contents("php://input"), true);

    $name  = trim($data['name'] ?? '');
    $sku   = trim($data['sku'] ?? '');
    $cat   = trim($data['category'] ?? '');
    $supId = !empty($data['supplier_id']) ? (int)$data['supplier_id'] : null;
    $price = (float)($data['price'] ?? 0);
    $min   = (int)($data['min'] ?? 0);
    $open  = (int)($data['opening'] ?? 0);

    if (!$name || !$sku)    die(json_encode(["error" => "Name and SKU are required."]));
    if ($price < 0 || $min < 0) die(json_encode(["error" => "Invalid price or minimum."]));

    // FR-023 / BR-004: unique SKU
    $chk = $conn->prepare("SELECT item_id FROM items WHERE sku = ?");
    $chk->bind_param("s", $sku);
    $chk->execute();
    if ($chk->get_result()->num_rows > 0) {
        die(json_encode(["error" => "SKU '$sku' is already in use."]));
    }

    $stmt = $conn->prepare("INSERT INTO items (sku, name, category, supplier_id, unit_price, min_stock) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sssidi", $sku, $name, $cat, $supId, $price, $min);
    $stmt->execute();
    $newId = $conn->insert_id;

    // BR-015: opening quantity as stock-in movement
    if ($open > 0) {
        $mv = $conn->prepare("INSERT INTO stock_movements (item_id, movement_date, type, quantity, unit_price, note, recorded_by) VALUES (?, CURDATE(), 'in', ?, ?, 'Opening stock', ?)");
        $mv->bind_param("iidi", $newId, $open, $price, $me['user_id']);
        $mv->execute();
    }

    logAudit($conn, $me['user_id'], 'create', 'items', $newId, "Created item $sku");
    echo json_encode(["success" => "Item created.", "id" => $newId]);
    exit;
}

// POST /api/items.php?action=update&id=X — edit item (FR-024)
if ($method === 'POST' && $action === 'update') {
    $id = (int)($_GET['id'] ?? 0);
    $data = json_decode(file_get_contents("php://input"), true);

    $name  = trim($data['name'] ?? '');
    $sku   = trim($data['sku'] ?? '');
    $cat   = trim($data['category'] ?? '');
    $supId = !empty($data['supplier_id']) ? (int)$data['supplier_id'] : null;
    $price = (float)($data['price'] ?? 0);
    $min   = (int)($data['min'] ?? 0);

    // Unique SKU check (excluding self)
    $chk = $conn->prepare("SELECT item_id FROM items WHERE sku = ? AND item_id != ?");
    $chk->bind_param("si", $sku, $id);
    $chk->execute();
    if ($chk->get_result()->num_rows > 0) {
        die(json_encode(["error" => "SKU '$sku' is already used by another item."]));
    }

    $stmt = $conn->prepare("UPDATE items SET sku = ?, name = ?, category = ?, supplier_id = ?, unit_price = ?, min_stock = ? WHERE item_id = ?");
    $stmt->bind_param("sssidii", $sku, $name, $cat, $supId, $price, $min, $id);
    $stmt->execute();

    logAudit($conn, $me['user_id'], 'update', 'items', $id, "Updated item $sku");
    echo json_encode(["success" => "Item updated."]);
    exit;
}

// POST /api/items.php?action=delete&id=X — admin only (FR-025, BR-008)
if ($method === 'POST' && $action === 'delete') {
    if ($me['role'] !== 'admin') {
        http_response_code(403);
        die(json_encode(["error" => "Only administrators can delete items."]));
    }
    $id = (int)($_GET['id'] ?? 0);
    $stmt = $conn->prepare("DELETE FROM items WHERE item_id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    logAudit($conn, $me['user_id'], 'delete', 'items', $id, "Deleted item");
    echo json_encode(["success" => "Item deleted."]);
    exit;
}

http_response_code(400);
echo json_encode(["error" => "Unknown action"]);