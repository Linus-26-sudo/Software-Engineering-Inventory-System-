<?php
// api/auth.php
session_start();
header('Content-Type: application/json');
require_once 'db.php';
require_once 'mailer.php';

$action = $_GET['action'] ?? '';

if ($action === 'signup') {
    $data = json_decode(file_get_contents("php://input"), true);
    
    // Validation (FR-005, FR-007)
    $name = trim($data['name'] ?? '');
    $email = filter_var($data['email'] ?? '', FILTER_VALIDATE_EMAIL);
    $password = $data['password'] ?? '';
    $role = $data['role'] === 'admin' ? 'admin' : 'staff';

    if (!$name || !$email || strlen($password) < 8) {
        die(json_encode(["error" => "Invalid input."]));
    }

    // Check if admin exists (FR-006)
    if ($role === 'admin') {
        $res = $conn->query("SELECT user_id FROM users WHERE role = 'admin'");
        if ($res->num_rows > 0) {
            die(json_encode(["error" => "Administrator already exists."]));
        }
    }

    // Check duplicate
    $stmt = $conn->prepare("SELECT user_id FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    if ($stmt->get_result()->num_rows > 0) {
        die(json_encode(["error" => "Email already in use."]));
    }

    // Hash & Insert (FR-008)
    $hash = password_hash($password, PASSWORD_BCRYPT);
    $stmt = $conn->prepare("INSERT INTO users (full_name, email, password_hash, role) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $name, $email, $hash, $role);
    $stmt->execute();
    
    echo json_encode(["success" => "Account created. Please sign in."]);
    exit;
}

if ($action === 'login') {
    $data = json_decode(file_get_contents("php://input"), true);
    $email = $data['email'] ?? '';
    $password = $data['password'] ?? '';

    $stmt = $conn->prepare("SELECT user_id, full_name, password_hash, role, is_active, locked_until, failed_attempts FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $user = $stmt->get_result()->fetch_assoc();

    if (!$user) {
        http_response_code(401);
        die(json_encode(["error" => "Account not found."]));
    }

    if (!$user['is_active']) {
        http_response_code(403); // <-- Tell the browser this is an ERROR
        die(json_encode(["error" => "Your account has been deactivated by the Administrator. Please contact the business owner for assistance."]));
    }

    // Lockout check (FR-012)
    if ($user['locked_until'] && strtotime($user['locked_until']) > time()) {
        http_response_code(403);
        die(json_encode(["error" => "Account locked. Try again later."]));
    }

    if (!password_verify($password, $user['password_hash'])) {
        http_response_code(401);
        // Increment failed attempts
        $attempts = $user['failed_attempts'] + 1;
        if ($attempts >= 5) {
            $lock = date('Y-m-d H:i:s', strtotime('+15 minutes'));
            $up = $conn->prepare("UPDATE users SET failed_attempts = 0, locked_until = ? WHERE user_id = ?");
            $up->bind_param("si", $lock, $user['user_id']);
            $up->execute();
            die(json_encode(["error" => "Too many attempts. Account locked for 15 minutes."]));
        } else {
            $up = $conn->prepare("UPDATE users SET failed_attempts = ? WHERE user_id = ?");
            $up->bind_param("ii", $attempts, $user['user_id']);
            $up->execute();
            die(json_encode(["error" => "Incorrect password."]));
        }
    }

    // Password correct - Reset attempts
    $conn->query("UPDATE users SET failed_attempts = 0 WHERE user_id = " . $user['user_id']);

    // Generate OTP (FR-009)
    $otp = sprintf("%06d", mt_rand(0, 999999));
    $otpHash = password_hash($otp, PASSWORD_BCRYPT);
    $expires = date('Y-m-d H:i:s', strtotime('+5 minutes'));

    $stmt = $conn->prepare("INSERT INTO otp_codes (user_id, code_hash, expires_at) VALUES (?, ?, ?)");
    $stmt->bind_param("iss", $user['user_id'], $otpHash, $expires);
    $stmt->execute();

    sendMfaCode($email, $otp);

    // Log to audit (FR-057)
    $conn->query("INSERT INTO audit_log (user_id, action, table_name, details) VALUES ({$user['user_id']}, 'login', 'users', 'Password accepted, OTP sent')");

    // Save user ID in session temporarily
    $_SESSION['temp_user_id'] = $user['user_id'];

    echo json_encode([
        "success" => "Password correct.", 
        "demo_code" => $otp // In a real app, remove this! This is for testing without email setup.
    ]);
    exit;
}

if ($action === 'verify_mfa') {
    $data = json_decode(file_get_contents("php://input"), true);
    $code = $data['code'] ?? '';
    $uid = $_SESSION['temp_user_id'] ?? null;

    if (!$uid) die(json_encode(["error" => "Session expired."]));

    $stmt = $conn->prepare("SELECT otp_id, code_hash, expires_at, attempts FROM otp_codes WHERE user_id = ? AND is_used = 0 ORDER BY otp_id DESC LIMIT 1");
    $stmt->bind_param("i", $uid);
    $stmt->execute();
    $otp = $stmt->get_result()->fetch_assoc();

    if (!$otp) die(json_encode(["error" => "No valid code found."]));

    if (strtotime($otp['expires_at']) < time()) {
        die(json_encode(["error" => "Code expired."]));
    }

    if ($otp['attempts'] >= 3) {
        die(json_encode(["error" => "Too many wrong codes. Sign in again."]));
    }

    if (!password_verify($code, $otp['code_hash'])) {
        $conn->query("UPDATE otp_codes SET attempts = attempts + 1 WHERE otp_id = {$otp['otp_id']}");
        die(json_encode(["error" => "Incorrect code."]));
    }

    // Success - mark used and create session
    $conn->query("UPDATE otp_codes SET is_used = 1 WHERE otp_id = {$otp['otp_id']}");
    $conn->query("UPDATE users SET last_login = NOW() WHERE user_id = $uid");

    // Get user for session
    $res = $conn->query("SELECT user_id, full_name, role FROM users WHERE user_id = $uid");
    $user = $res->fetch_assoc();

    $_SESSION['user'] = $user;
    unset($_SESSION['temp_user_id']);

    echo json_encode(["success" => "Authenticated", "user" => $user]);
    exit;
}

if ($action === 'resend_mfa') {
    $uid = $_SESSION['temp_user_id'] ?? null;
    if (!$uid) die(json_encode(["error" => "Session expired. Sign in again."]));

    // Check the most recent OTP's age
    $res = $conn->query("SELECT created_at FROM otp_codes WHERE user_id = $uid ORDER BY otp_id DESC LIMIT 1");
    if ($res->num_rows > 0) {
        $last = $res->fetch_assoc();
        if (strtotime($last['created_at']) + 60 > time()) {
            $wait = 60 - (time() - strtotime($last['created_at']));
            die(json_encode(["error" => "Wait {$wait} seconds before requesting a new code."]));
        }
    }

    // Create a new code
    $otp = sprintf("%06d", mt_rand(0, 999999));
    $hash = password_hash($otp, PASSWORD_BCRYPT);
    $exp  = date('Y-m-d H:i:s', strtotime('+5 minutes'));

    // Mark all previous codes unused -> invalid
    $conn->query("UPDATE otp_codes SET is_used = 1 WHERE user_id = $uid AND is_used = 0");

    $stmt = $conn->prepare("INSERT INTO otp_codes (user_id, code_hash, expires_at) VALUES (?, ?, ?)");
    $stmt->bind_param("iss", $uid, $hash, $exp);
    $stmt->execute();

    $emailRow = $conn->query("SELECT email FROM users WHERE user_id = $uid")->fetch_assoc();
    sendMfaCode($emailRow['email'], $otp);

    echo json_encode([
        "success"    => "New code sent.",
        "demo_code"  => $otp   // remove in production
    ]);
    exit;
}

// ==========================================
// FORGOT PASSWORD: Request a reset code
// ==========================================
if ($action === 'forgot') {
    $data = json_decode(file_get_contents("php://input"), true);
    $email = filter_var($data['email'] ?? '', FILTER_VALIDATE_EMAIL);

    if (!$email) die(json_encode(["error" => "Invalid email address."]));

    $stmt = $conn->prepare("SELECT user_id FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $user = $stmt->get_result()->fetch_assoc();

    if (!$user) {
        // For security, don't reveal if the email exists or not, just say it's sent
        die(json_encode(["success" => "If that email exists, a code was sent.", "demo_code" => null]));
    }

    // Generate code
    $otp = sprintf("%06d", mt_rand(0, 999999));
    $hash = password_hash($otp, PASSWORD_BCRYPT);
    $exp = date('Y-m-d H:i:s', strtotime('+15 minutes')); // 15 min expiry for resets

    // Save to password_resets table
    $stmt = $conn->prepare("INSERT INTO password_resets (user_id, code_hash, expires_at) VALUES (?, ?, ?)");
    $stmt->bind_param("iss", $user['user_id'], $hash, $exp);
    $stmt->execute();

    sendMfaCode($email, $otp);

    echo json_encode([
        "success" => "If that email exists, a code was sent.", 
        "demo_code" => $otp // Remove in production
    ]);
    exit;
}

// ==========================================
// RESET PASSWORD: Verify code and save new password
// ==========================================
if ($action === 'reset') {
    $data = json_decode(file_get_contents("php://input"), true);
    $email = filter_var($data['email'] ?? '', FILTER_VALIDATE_EMAIL);
    $code  = $data['code'] ?? '';
    $newPw = $data['password'] ?? '';

    if (!$email || strlen($code) !== 6 || strlen($newPw) < 8) {
        die(json_encode(["error" => "Invalid input. Password must be 8+ characters."]));
    }

    // Find user
    $stmt = $conn->prepare("SELECT user_id FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $user = $stmt->get_result()->fetch_assoc();

    if (!$user) die(json_encode(["error" => "Invalid request."]));

    // Find latest valid reset code
    $stmt = $conn->prepare("SELECT reset_id, code_hash, expires_at FROM password_resets WHERE user_id = ? AND is_used = 0 ORDER BY reset_id DESC LIMIT 1");
    $stmt->bind_param("i", $user['user_id']);
    $stmt->execute();
    $reset = $stmt->get_result()->fetch_assoc();

    if (!$reset) die(json_encode(["error" => "No active reset code found."]));

    if (strtotime($reset['expires_at']) < time()) {
        die(json_encode(["error" => "Code has expired. Please request a new one."]));
    }

    if (!password_verify($code, $reset['code_hash'])) {
        die(json_encode(["error" => "Incorrect code."]));
    }

    // Code is correct! Update password
    $newHash = password_hash($newPw, PASSWORD_BCRYPT);
    $upUser = $conn->prepare("UPDATE users SET password_hash = ? WHERE user_id = ?");
    $upUser->bind_param("si", $newHash, $user['user_id']);
    $upUser->execute();

    // Mark code as used
    $conn->query("UPDATE password_resets SET is_used = 1 WHERE reset_id = {$reset['reset_id']}");

    echo json_encode(["success" => "Password updated successfully. You can now log in."]);
    exit;
}

if ($action === 'session') {
    if (isset($_SESSION['user'])) {
        echo json_encode(["user" => $_SESSION['user']]);
    } else {
        http_response_code(401);
        echo json_encode(["error" => "Unauthorized"]);
    }
    exit;
}

if ($action === 'logout') {
    session_destroy();
    echo json_encode(["success" => "Logged out"]);
    exit;
}
?>