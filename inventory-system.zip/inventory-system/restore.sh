#!/bin/bash
# ============================================================
# Restore a backup file. NFR-009 requires <2 hours recovery.
#
# Usage:
#   ./restore.sh /var/backups/inventory/inventory_db_20261029_020000.sql.gz
# ============================================================

if [ -z "$1" ] || [ ! -f "$1" ]; then
    echo "Usage: $0 <path-to-backup.sql.gz>" >&2
    exit 1
fi

read -p "Restore $1 to inventory_db? This will overwrite current data. [y/N] " confirm
if [ "$confirm" != "y" ]; then
    echo "Aborted."
    exit 0
fi

gunzip -c "$1" | mysql -u root -p inventory_db
echo "Restore complete."